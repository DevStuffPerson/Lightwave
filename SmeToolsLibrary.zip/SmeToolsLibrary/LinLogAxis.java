/** 
* MODULE NAME:                              LinLogAxis.java
* SOURCE CODE CLASSIFICATION:               UNCLASSIFIED 
* HIGHEST CLASSIFICATION OF INPUT DATA:     UNCLASSIFIED 
* HIGHEST CLASSIFICATION OF OUTPUT DATA:    UNCLASSIFIED 
* OWNER:                                    23ANS/ANA 
* AUTHOR:                                   David Smuck 
* CREATION DATE:                            07 Oct 2019 
* PURPOSE: 
* This program implements a combined linear-logarithmic axis use in JavaFX line 
* charts. The code inspired by an implementation for a base-10 logarithmic 
* axis by Kevin Senechal, ref: https://gist.githum.com/kevinsdooapp/3227204 
* This code applies a linear scale for values below 1 and a base-10 logarithmic 
* scale for values above 1. 
* 
* INPUTS : ... 
* 
* OUTPUTS: 
* 
* REVISION HISTORY: 
* DATE          MOD-BY          DESCRIPTION 
* -----------   --------------  ------------------------------------------------
* 02 Oct 2019   David Smuck     Original Version
*
*/

package SmeToolsLibrary;


//import java.text.NumberFormat;
//import java . util . ArrayList;
//import java.util .List;
//import javafx . animation . KeyFrame;
//import javafx . animation . KeyValue;
//import javafx.animat ion.Timeline;
//import javafx.beans.bi nding.DoubleBinding;
//import javafx . beans.property. DoubleProperty;
//import javafx.beans .property.SimpleDoubleProperty;
//import javafx . scene . chart.ValueAxis;
//import javafx . uti l . Duration;


import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.binding.DoubleBinding;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.chart.ValueAxis;
import javafx.util.Duration;

public class LinLogAxis extends ValueAxis<Number> { 
    private static final double ANIMATION_TIME = 2000;
    private final Timeline lowerRangeTimeline = new Timeline();
    private final Timeline upperRangeTimeline = new Timeline();
    private final DoubleProperty linLogUpperBound = new SimpleDoubleProperty();
    private final DoubleProperty linLogLowerBound = new SimpleDoubleProperty();
    private final double minorLinTickMarkValue = 0.1;
    
    public LinLogAxis() {
        super (-0.5, 10.0);
        bindLinLogBoundsToDefaultBounds();
    }
    
    public LinLogAxis(double lowerBound, double upperBound) {
        super (lowerBound, upperBound);
        try { 
            validateBounds(lowerBound, upperBound);
            bindLinLogBoundsToDefaultBounds();
//        } catch (IllegalLogarithmicRangeException e) {
        } catch (Exception e) {
        } 
    } 
    
    /** 
     * Bind the combined linear-logarithmic bounds with the super class bounds 
     */ 
    private void bindLinLogBoundsToDefaultBounds() {
        linLogLowerBound.bind(new DoubleBinding() { 
            {
                super.bind(lowerBoundProperty());
            } 
            @Override 
            protected double computeValue() {
                return valueToLinLogValue(lowerBoundProperty().get());
            }
        });
        linLogUpperBound.bind(new DoubleBinding() { 
            { 
                super.bind(upperBoundProperty());
            }
            @Override 
            protected double computeValue() {
                return valueToLinLogValue(upperBoundProperty().get());
            }
        });
    }

    /** 
     * Validate the bounds by throwing an exception if the lower bound is 
     * greater than the upper bound 
     */
    //private void validateBounds (double lowerBound , double upperBound) throws IllegalLogarithmicRangeException {
    private void validateBounds (double lowerBound , double upperBound) throws Exception {
        if (lowerBound > upperBound) {
            //throw new IllegalLogarithmicRangeException ("The lower bound is greater than the upper bound.");
            throw new Exception ("The lower bound is greater than the upper bound.");
        }
    }
        
    /** 
     * {@inheritDoc} 
     */ 
    @Override 
    protected void setRange(Object range, boolean animate) {
        if (range != null) {
            Number lowerBound = ((Number[]) range)[0];
            Number upperBound = ((Number[]) range)[1];
            try {
                validateBounds(lowerBound.doubleValue(), upperBound.doubleValue());
            //} catch (IllegalLogarithmicRangeException e) {
            } catch (Exception e) {
            }
            if (animate) {
                try {
                    lowerRangeTimeline.getKeyFrames().clear();
                    upperRangeTimeline.getKeyFrames().clear();
                    lowerRangeTimeline.getKeyFrames().addAll(new KeyFrame(Duration.ZERO,
                            new KeyValue(lowerBoundProperty(), lowerBoundProperty().get())),
                            new KeyFrame(new Duration(ANIMATION_TIME),
                            new KeyValue(lowerBoundProperty(), lowerBound.doubleValue())));
                    upperRangeTimeline.getKeyFrames().addAll(new KeyFrame(Duration.ZERO,
                            new KeyValue(upperBoundProperty(), upperBoundProperty().get())),
                            new KeyFrame(new Duration(ANIMATION_TIME),
                            new KeyValue(upperBoundProperty(), upperBound.doubleValue())));
                    lowerRangeTimeline.play();
                    upperRangeTimeline.play();
                } catch (Exception e) {
                    lowerBoundProperty().set(lowerBound.doubleValue());
                    upperBoundProperty().set(upperBound.doubleValue());
                }
                lowerBoundProperty().set(lowerBound.doubleValue());
                upperBoundProperty().set(upperBound.doubleValue());
            }
        }
    }

    @Override
    protected Number[] getRange() {
        return new Number[]{lowerBoundProperty().get(), upperBoundProperty().get()};
    }

    /**
     * @return tic mark values based on reasonable range for calling
     * application. For a more general application, these should be calculated
     * based on the given range. See reference code (details in class header) for an example.
     */
    @Override
    protected List<Number> calculateTickValues(double length, Object range) {
        List<Number> tickPositions = new ArrayList<>();
        tickPositions.add(-3.0);
        tickPositions.add(-2.5);
        tickPositions.add(-2.0);
        tickPositions.add(-1.5);
        tickPositions.add(-1.0);
        tickPositions.add(-0.5);
        tickPositions.add(0.0);
        tickPositions.add(0.5);
        tickPositions.add(1);
        tickPositions.add(1E1);
        tickPositions.add(1E2);
        tickPositions.add(1E3);
        tickPositions.add(1E4);
        tickPositions.add(1E5);
        tickPositions.add(1E6);
        tickPositions.add(1E7);
        tickPositions.add(1E8);
        tickPositions.add(1E9);
        tickPositions.add(1E10);
        tickPositions.add(1E11);
        tickPositions.add(1E12);
        return tickPositions;
    }

    /**
     * @return minor tic mark values, using a constant value for the linear
     * scale portion and adjusting every base-10 logarithmic decade for the
     * logarithmic scale.
     */
    @Override
    protected List<Number> calculateMinorTickMarks() {
        Number[] range = getRange();
        List<Number> minorTickMarksPositions = new ArrayList<>();
        if (range != null) {
            double i = linLogLowerBound.get();
            while (i < linLogUpperBound.get()) {
                if (i < 1.0) {
                    double ii = Math.round(i*10.0)/10.0;
                    minorTickMarksPositions.add(ii);
                    i += minorLinTickMarkValue;
                } else {
                    for (double j=1.0; j<=9; j+=1) {
                        double jj = j * Math.pow(10.0, Math.round(i-1.0));
                        minorTickMarksPositions.add(jj);
                    } 
                    i++;
                }
            }
        }
        return minorTickMarksPositions;
    }
    
    /**
     * @return tic mark labels using exponential notation for all values larger
     * than 10. Default case returns something if an unexpected range is used.
     */
    @Override 
    protected String getTickMarkLabel(Number value) {
        switch (value.intValue()) {
            case 100:
                return "10\u00B2";
            case 1000:
                return "10\u00B3";
            case 10000:
                return "10\u2074";
            case 100000:
                return "10\u2075";
            case 1000000:
                return "10\u2076";
            case 10000000:
                return "10\u2077";
            case 100000000:
                return "10\u2078";
            case 1000000000:
                return "10\u2079";
            default:
                NumberFormat formatter = NumberFormat.getInstance();
                formatter.setMaximumIntegerDigits(6);
                formatter.setMinimumIntegerDigits(1);
                return formatter.format(value);
        }
    }

    /**
     * @return t he value to plot the point on the display (a linear scale) to
     * create the linear-logarithmic scale effect.
     */
    @Override
    public double getDisplayPosition(Number value) {
        double delta = linLogUpperBound.get() - linLogLowerBound.get();
        double linLogValue = valueToLinLogValue(value.doubleValue());
        double deltaV = linLogValue - linLogLowerBound.get();
        if (getSide().isVertical()) {
            return (1.0 - (deltaV / delta)) * getHeight();
        } else {
            return (deltaV / delta) * getWidth();
        }
    }

    /**
     * @return the actual value corresponding to the provided display position
     * (a linear scale).
     */
    @Override
    public Number getValueForDisplay(double displayPosition) {
        double delta = linLogUpperBound.get() - linLogLowerBound.get();
        double deltaV;
        if (getSide().isVertical()) { 
            deltaV = (1.0 - displayPosition/getHeight()) * delta;
        } else {
            deltaV = (delta * displayPosition)/getWidth();
        }
        double linLogValue = deltaV + linLogLowerBound.get();
        return linLogValueToValue(linLogValue);
    }

    /**
     * @return the display value (in linear space) corresponding to the
     * @param value to create the effect of the linear-logarithmic scale.
     */
    protected double valueToLinLogValue(double value) {
        if (value <= 1.0) { 
            return value;
        } else {
            return (1 + Math.log10(value));
        }
    }
    
    /**
     * @return the actual value corresponding t o the
     * @param linLogValue used on the linear-logarithmic display axis.
     */
    protected double linLogValueToValue (double linLogValue) { 
        if (linLogValue <= 1.0) {
            return linLogValue;
        } else {
            return Math.pow(10.0,(linLogValue - 1));
        }
    }
    
}

