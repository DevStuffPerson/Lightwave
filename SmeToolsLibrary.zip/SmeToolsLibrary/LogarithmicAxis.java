/** 
* MODULE NAME:                              LinLogAxis.java
* SOURCE CODE CLASSIFICATION:               UNCLASSIFIED 
* HIGHEST CLASSIFICATION OF INPUT DATA:     System high 
* HIGHEST CLASSIFICATION OF OUTPUT DATA:    Ssytem high 
* OWNER:                                    23ANS/ANA 
* AUTHOR:                                   David Smuck 
* CREATION DATE:                            02 Oct 2019 
* 
* PURPOSE: 
* This program implements a base- 10 logarithmic axis for use in JavaFX line
* charts. The code based on an implementation by Kevin Senechal, ref:
* https://gist.githnb.com/kevinsdooapp/3227204 with minor customization and
* addition of exponential notation for tic mark values.
* 
* INPUTS: 
* 
* OUTPUTS: 
* 
* REVISION HISTORY: 
* DATE          MOD-BY          DESCRIPTION 
* -----------   --------------  ------------------------------------------------
* 02 Oct 2019   David Smuck     Original Version
*
*/

package SmeToolsLibrary;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.binding.DoubleBinding;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.chart.ValueAxis;
import javafx.util.Duration;

public class LogarithmicAxis extends ValueAxis<Number> { 
    private static final double ANIMATION_TIME = 2000;
    private final Timeline lowerRangeTimeline = new Timeline();
    private final Timeline upperRangeTimeline = new Timeline();
    private final DoubleProperty logUpperBound = new SimpleDoubleProperty();
    private final DoubleProperty logLowerBound = new SimpleDoubleProperty();
    
    public LogarithmicAxis() {
        super (1, 100);
        bindLogBoundsToDefaultBounds();
    }
    
    public LogarithmicAxis(double lowerBound, double upperBound) {
        super (lowerBound, upperBound);
        try { 
            validateBounds(lowerBound, upperBound);
            bindLogBoundsToDefaultBounds();
        } catch (Exception e) {
        } 
    } 
    
    /** 
     * Bind the logarithmic bounds with the super class bounds 
     */ 
    private void bindLogBoundsToDefaultBounds() {
        logLowerBound.bind(new DoubleBinding() { 
            {
                super.bind(lowerBoundProperty());
            } 
            @Override 
            protected double computeValue() {
                return Math.log10(lowerBoundProperty().get());
            }
        });
        logUpperBound.bind(new DoubleBinding() { 
            { 
                super.bind(upperBoundProperty());
            }
            @Override 
            protected double computeValue() {
                return Math.log10(upperBoundProperty().get());
            }
        });
    }

    /** 
     * Validate the bounds by throwing an exception if the the values do not
     * conform to the mathematics log interval (cannot be negative) 
     */
    private void validateBounds (double lowerBound , double upperBound) throws Exception {
        if (lowerBound <= 0 || upperBound <= 0 || lowerBound > upperBound) {
            throw new Exception("The logarithmic range should be greater than " +
                    "zero and the lowcr Bound should be less than the upperBound");
        }
    }
        
    /** 
     * {@inheritDoc} 
     */ 
    @Override 
    protected void setRange(Object range, boolean animate) {
        if (range != null) {
            Number lowerBound = ((Number[]) range)[0];
            Number upperBound = ((Number[]) range)[1];
            try {
                validateBounds(lowerBound.doubleValue(), upperBound.doubleValue());
            } catch (Exception e) {
            }
            if (animate) {
                try {
                    lowerRangeTimeline.getKeyFrames().clear();
                    upperRangeTimeline.getKeyFrames().clear();
                    lowerRangeTimeline.getKeyFrames().addAll(new KeyFrame(Duration.ZERO,
                            new KeyValue(lowerBoundProperty(), lowerBoundProperty().get())),
                            new KeyFrame(new Duration(ANIMATION_TIME),
                            new KeyValue(lowerBoundProperty(), lowerBound.doubleValue())));
                    upperRangeTimeline.getKeyFrames().addAll(new KeyFrame(Duration.ZERO,
                            new KeyValue(upperBoundProperty(), upperBoundProperty().get())),
                            new KeyFrame(new Duration(ANIMATION_TIME),
                            new KeyValue(upperBoundProperty(), upperBound.doubleValue())));
                    lowerRangeTimeline.play();
                    upperRangeTimeline.play();
                } catch (Exception e) {
                    lowerBoundProperty().set(lowerBound.doubleValue());
                    upperBoundProperty().set(upperBound.doubleValue());
                }
                lowerBoundProperty().set(lowerBound.doubleValue());
                upperBoundProperty().set(upperBound.doubleValue());
            }
        }
    }

    @Override
    protected Number[] getRange() {
        return new Number[] {lowerBoundProperty().get(), upperBoundProperty().get()};
    }

    /**
     * @return tic mark values based on reasonable range for calling
     * application. For a more general application, these should be calculated
     * based on the given range. See reference code (details in class header) for an example.
     */
    @Override
    protected List<Number> calculateTickValues(double length, Object range) {
        List<Number> tickPositions = new ArrayList<>();
        tickPositions.add(1E-7);
        tickPositions.add(1E-6);
        tickPositions.add(1E-5);
        tickPositions.add(1E-4);
        tickPositions.add(1E-3);
        tickPositions.add(1E-2);
        tickPositions.add(1E-1);
        tickPositions.add(1);
        tickPositions.add(1E1);
        tickPositions.add(1E2);
        tickPositions.add(1E3);
        tickPositions.add(1E4);
        tickPositions.add(1E5);
        tickPositions.add(1E6);
        tickPositions.add(1E7);
        tickPositions.add(1E8);
        tickPositions.add(1E9);
        tickPositions.add(1E10);
        tickPositions.add(1E11);
        tickPositions.add(1E12);
        tickPositions.add(1E13);
        tickPositions.add(1E14);
        tickPositions.add(1E15);
        return tickPositions;
    }

    /**
     * @return minor tic mark values, adjusting every base-10 logarithmic decade.
     */
    @Override
    protected List<Number> calculateMinorTickMarks() {
        Number[] range = getRange();
        List<Number> minorTickMarksPositions = new ArrayList<>();
        if (range != null) {
            double i = logLowerBound.get();
            while (i <= logUpperBound.get()) {
                for (double j=1.0; j<=9; j+=1) {
                    double jj = j * Math.pow(10.0, Math.round(i-1.0));
                    minorTickMarksPositions.add(jj);
                } 
                i++;
            }
        }
        return minorTickMarksPositions;
    }
    
    /**
     * @return tic mark labels using exponential notation for all values except
     * l and 10.  Else case returns something if an unexpected range is used.
     */
    @Override 
    protected String getTickMarkLabel(Number value) {
        switch (value.intValue()) {
            case 1:
                return "1";
            case 10:
                return "10";
            case 100:
                return "10\u00B2";
            case 1000:
                return "10\u00B3";
            case 10000:
                return "10\u2074";
            case 100000:
                return "10\u2075";
            case 1000000:
                return "10\u2076";
            case 10000000:
                return "10\u2077";
            case 100000000:
                return "10\u2078";
            case 1000000000:
                return "10\u2079";
        }
        if (value.doubleValue() > 1E-8 && value.doubleValue()< 1E-6){
            return "10\u207B\u2077";
        } else if (value.doubleValue() > 1E-7 && value.doubleValue() < 1E-5) {
            return "10\u207B\u2076";
        } else if (value.doubleValue() > 1E-6 && value.doubleValue() < 1E-4) {
            return "10\u207B\u2075";
        } else if (value.doubleValue() > 1E-5 && value.doubleValue() < 1E-3) {
            return "10\u207B\u2074";
        } else if (value.doubleValue() > 1E-4 && value.doubleValue() < 1E-2) {
            return "10\u207B\u00B3";
        } else if (value.doubleValue() > 1E-3 && value.doubleValue() < 1E-1) {
            return "10\u207B\u00B2";
        } else if (value.doubleValue() > 1E-2 && value.doubleValue() < 1) {
            return "10\u207B\u00B9";
        } else if (value.doubleValue() > 1E9 && value.doubleValue() < 1E11) {
            return "10\u00B9\u2070";
        } else if (value.doubleValue() > 1E10 && value.doubleValue() < 1E12) {
            return "10\u00B9\u00B9";
        } else if (value.doubleValue() > 1E11 && value.doubleValue() < 1E13) {
            return "10\u00B9\u00B2";
        } else if (value.doubleValue() > 1E12 && value.doubleValue() < 1E14) {
            return "10\u00B9\u00B3";
        } else if (value.doubleValue() > 1E13 && value.doubleValue() < 1E15) {
            return "10\u00B9\u2074";
        } else if (value.doubleValue() > 1E14 && value.doubleValue() < 1E16) {
            return "10\u00B9\u2075";
        } else {
            NumberFormat formatter = NumberFormat.getInstance();
            formatter.setMaximumIntegerDigits(15);
            formatter.setMinimumIntegerDigits(1);
            return formatter.format(value);
        }
    }

    /**
     * @return the value to plot the point on the display (a linear scale) to
     * create the logarithmic scale effect.
     */
    @Override
    public double getDisplayPosition(Number value) {
        double delta = logUpperBound.get() - logLowerBound.get();
        double deltaV = Math.log10(value.doubleValue()) - logLowerBound.get();
        if (getSide().isVertical()) {
            return (1.0 - (deltaV / delta)) * getHeight();
        } else {
            return (deltaV / delta) * getWidth();
        }
    }
        
    /**
     * @return the actual value corresponding to the provided display position
     * (a linear scale).
     */
    @Override
    public Number getValueForDisplay(double displayPosition) {
        double delta = logUpperBound.get() - logLowerBound.get();
        if (getSide().isVertical()) {
            return Math.pow(10, (((displayPosition - getHeight()) / -getHeight()) * delta) + logLowerBound.get());
        } else {
            return Math.pow(10, (((displayPosition / getWidth()) * delta) + logLowerBound.get()));
        }
    }
    
}

