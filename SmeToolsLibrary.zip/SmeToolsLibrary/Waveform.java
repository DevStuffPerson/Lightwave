/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SmeToolsLibrary;

import java.util.Arrays;

/**
 *
 * @author David Smuck
 */
public class Waveform {

    double[] xValues;
    double[] yValues; 
    // Optional Descriptors
    double azimuth; // in degrees 
    double comparisonStartTime;
    double comparisonStopTime;
    double heightOfBurst; // in meters 
    double lookAngle; // in degrees 
    double mass; // in kg
    double pcc;
    double sev;
    double yield; //in tons 
    int band; // HYCHEM band number 
    int nSamples;
    String bandLabel;
    String dateTime = "";
    String fineTime = "";
    String surfaceMaterial;
    String xUnits;
    String yUnits;
    String iron;
    String tagNumber;
    String eproType;
    String dateTimeFineTime;
    String dataSource;

    
    // Constructors 
    public Waveform() {
        System.out.println("In the basic Waveform class constructor");
        this.pcc = -1.0;
    }

    public Waveform(double[] xValues, double[] yValues) {
        this.xValues = Arrays.copyOf(xValues, xValues.length);
        this.yValues = Arrays.copyOf(yValues, yValues.length);
//        System.out.println("In the Waveform class XY constructor"); 
//        System.out.println("xValues = " + Arrays.toString(xValues)); 
//        System.out.println("yValues = " + Arrays.toString(yValues)); 
//        
        this.pcc = -1.0;
    }

    // Setters 
    public void setXValues(double[] xValues) {
        this.xValues = Arrays.copyOf(xValues, xValues.length);
    }

    public void setYValues(double[] yValues) {
        // System.out.println("In the Waveform classsetYValues setter"); 
        // System.out.println("yValues =" + Arrays.toString(yValues)); 
        // System.out.println("yValues.length =" + yValues.length); 
        this.yValues = Arrays.copyOf(yValues, yValues.length);
    }

    public void setAzimuth(double azimuth) {
        this.azimuth = azimuth;
    }

    public void setComparisonStartTime(double comparisonStartTime) {
        this.comparisonStartTime = comparisonStartTime;
        // Snap the time to the closest equal or lower time in the xValues array
        // Set equal to first value if less than that value 
        // Adjust Comparison Stop Time if new Start Time is after previous Stop Time 
        if (this.comparisonStartTime < xValues[0]) {
            // If input time is less than first sample, set as first sample
            this.comparisonStartTime = xValues[0];
            System.out.println("comparisonStartTime is before first sample");
        } else if (this.comparisonStartTime > xValues[xValues.length - 2]) {
            // If input time is greater than last sample, set as second to last sample (allows last sample to be stop time)
            this.comparisonStartTime = xValues[xValues.length - 2];
            System.out.println("comparisonStartTime is after the second to last sample");
        } else {
            // Iterate through xValues array to find the largest value less than the input time
            int ii = 1;
            while (this.comparisonStartTime >= xValues[ii]) {
                // System.out.println("ii = " + ii);
                // System.out.println("this.comparisonStartTime > xValues[ii] " + this.comparisonStartTime + " > " + xValues[ii]);
                ii++;
            }
            this.comparisonStartTime = xValues[ii - 1];
            System.out.println("this.comparisonStartTime is now equal to" + this.comparisonStartTime);
        }
    }

    public void setComparisonStopTime(double comparisonStopTime) {
        this.comparisonStopTime = comparisonStopTime;
        // Snap the time to the closest equal or higher time in the xValues array 
        // Set equal to last value if higher than that value 
        // Adjust Comparison Start Time if new Stop Time is before previous Start Time 
        if (this.comparisonStopTime > xValues[xValues.length - 1]) {
            // If input time is greater than l ast sample, set as last sample 
            this.comparisonStopTime = xValues[xValues.length - 1];
            System.out.println("comparisonStopTime is after last sample");
        } else if (this.comparisonStopTime < xValues[1]) {
            // If input time is less than second sample, set as second sample (allows first sample to be start time) 
            this.comparisonStopTime = xValues[1];
            System.out.println("comparisonStopTime is before the second sample");
        } else {
            // Iterate through xValues array to find the smalest value greater than the input time 
            int ii = xValues.length - 2;
            while (this.comparisonStopTime <= xValues[ii]) {
                //System.out.println("ii = " + ii);
                //System.out.println("this.comparisonStopTime < xValues [ii] " + this.comparisonStopTime + " < "+ xValues[ii]);
                ii--;
            }
            this.comparisonStopTime = xValues[ii + 1];
            //System.out.println("this.comparisonStopTime is now equal to " + this.comparisonStopTime);
        }
    }

    public void setHeightOfBurst(double heightOfBurst) {
        this.heightOfBurst = heightOfBurst;
    }

    public void setLookAngle(double lookAngle) {
        this.lookAngle = lookAngle;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    public void setYield(double yield) {
        this.yield = yield;
    }

    public void setBand(int band) {
        this.band = band;
    }

    public void setBandLabel(String bandLabel) {
        this.bandLabel = bandLabel;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
        this.dateTimeFineTime = this.dateTime + " " + this.fineTime;
    }

    public void setFineTime(String fineTime) {
        this.fineTime = fineTime;
        this.dateTimeFineTime = this.dateTime + "." + this.fineTime;
    }

    public void setSurfaceMaterial(String surfaceMaterial) {
        this.surfaceMaterial = surfaceMaterial;
    }

    public void setXUnits(String xUnits) {
        this.xUnits = xUnits;
    }

    public void setYUnits(String yUnits) {
        this.yUnits = yUnits;
    }

    public void setTagNumber(String tagNumber) {
        this.tagNumber = tagNumber;
    }

    public void setIron(String iron) {
        this.iron = iron;
    }

    public void setPcc(double pcc) {
        this.pcc = pcc;
    }

    public void setSev(double sev) {
        this.sev = sev;
    }

    public void setEproType(String eproType) {
        this.eproType = eproType;
    }

    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }


    
    
    
    // Getters 
    public double[] getXValues() {
        return Arrays.copyOf(xValues, xValues.length);
    }

    public double[] getYValues() {
        return Arrays.copyOf(yValues, yValues.length);
    }

    public double getAzirnuth() {
        return azimuth;
    }

    public double getComparisonStartTime() {
        return comparisonStartTime;
    }

    public double getComparisonStopTime() {
        return comparisonStopTime;
    }

    public double getHeightOfBurst() {
        return heightOfBurst;
    }

    public double getLookAngle() {
        return lookAngle;
    }

    public double getMass() {
        return mass;
    }

    public double getYield() {
        return yield;
    }

    public int getBand() {
        return band;
    }

    public int getNSamples() {
        return xValues.length;
    }

    public String getBandLabel() {
        return bandLabel;
    }

    public String getDateTime() {
        return dateTime;
    }

    public String getFineTime() {
        return fineTime;
    }

    public String getSurfaceMaterial() {
        return surfaceMaterial;
    }

    public String getXUnits() {
        return xUnits;
    }

    public String getYUnits() {
        return yUnits;
    }

    public String getTagNumber() {
        return tagNumber;
    }

    public String getIron() {
        return iron;
    }

    public double getPcc() {
        return pcc;
    }

    public double getSev() {
        return sev;
    }

    public String getEproType() {
        return eproType;
    }

    public String getDateTimeFineTime() {
        return dateTimeFineTime;
    }

    public String getDataSource() {
        return dataSource;
    }

    
    
    // Methods 
    public void resetComparisonTimes() {
        comparisonStartTime = xValues[0];
        comparisonStopTime = xValues[xValues.length - 1];
    }

}