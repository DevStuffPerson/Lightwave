/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SmeToolsLibrary;

import java.util.Arrays;

/**
 *
 * @author David Smuck
 */
public class WaveformComparison {

    public static double calculatePcc(double[] xSeries1, double[] ySeries1, double[] xS2,
            double[] yS2, int startSample, int stopSample, String pccControl) {
// System. out.println("\n\n\ninside the PCC calculation function " ); // System . out . println("xSeries1 : "+ Arrays . toString(xSeries1)); // System. out . println("ySeries1: "+ Arrays . toString(ySeries1)); // System.out.println("xS2: "+ Arrays.toString(xS2)); // System.out . println("yS2: "+ Arrays . toString(yS2)); // System.out.println("startSample: "+ startSample); // System.out.println("stopSample: "+ stopSample); // System. out . println("pccControl: " + pccControl); 
        double[] xSeries2;
        double[] ySeries2;
        // Test if two input waveforms have exactly the same x-values (time) steps 
        // If so , assign x and y seri es and proceed, if not , map/interpolate waveform2 y-values onto waveforml x-values (timesteps) 
        if (Arrays.equals(xSeries1, xS2)) { //waveforms have same x-values (time steps) 
            xSeries2 = xS2; //never used
            ySeries2 = yS2;
        } else { //waveforms have different x-values (time steps) 
            // copy series 1 x-values to new series 2 x-values 
            xSeries2 = Arrays.copyOf(xSeries1, xSeries1.length);
            // interpolate series 2 y-values for all new x-values 
            ySeries2 = splineInterpolator(xS2, yS2, xSeries2); //args: original x, original y, new x 
        }
        double pcc, ax = 0, ay = 0, syy = 0, sxy = 0, sxx = 0, yt, xt;
        int kk, n = 0;
        boolean includeSample;
        // calculate means
        for (kk = startSample - 1; kk < stopSample; kk++) {
            //System.out.println("waveformComparison.calculatePcc pcc " + pccControl);
            includeSample = false;
            switch (pccControl) {
                case "Reference waveform > 0":
                    if (ySeries1[kk] > 0.0) {
                        includeSample = true;
                    }
                    break;
                case "Comparison waveform > 0":
                    if (ySeries2[kk] > 0.0) {
                        includeSample = true;
                    }
                    break;
                case "Both waveforms > 0":
                    if (ySeries1[kk] > 0.0 && ySeries2[kk] > 0.0) {
                        includeSample = true;
                    }
                    break;
                default: // case "Include all samples ": and default are the same
                    includeSample = true;
                    break;
            }
            if (includeSample) {
                ax = ax + ySeries1[kk];
                ay = ay + ySeries2[kk];
                n++;
            }
        }
        ax = ax / n;
        ay = ay / n;
        //compute correlation coefficient 
        for (kk = startSample - 1; kk < stopSample; kk++) {
            includeSample = false;
            switch (pccControl) {
                case "Reference waveform > 0":
                    if (ySeries1[kk] > 0.0) {
                        includeSample = true;
                    }
                    break;
                case "Comparison waveform > 0":
                    if (ySeries2[kk] > 0.0) {
                        includeSample = true;
                    }
                    break;
                case "Both waveforms > 0":
                    if (ySeries1[kk] > 0.0 && ySeries2[kk] > 0.0) {
                        includeSample = true;
                    }
                    break;
                default:
                    includeSample = true;
                    break;
            }
            if (includeSample) {
                xt = ySeries1[kk] - ax;
                yt = ySeries2[kk] - ay;
                sxx = sxx + (xt * xt);
                syy = syy + (yt * yt);
                sxy = sxy + (xt * yt);
            }
        }
        //System.out.println("sxx , syy, sxy: " + sxx + " " + syy + " " + sxy); 
        if (sxx == 0.0 || syy == 0) {
            pcc = -1;
        } else {
            pcc = sxy / (Math.sqrt(sxx) * Math.sqrt(syy));
        }
        //System.out.println("returning pcc of " + pcc);
        return pcc;
    }

    /* Spline Interpolator
     * Based on Numerical recipes in C++. Second Ed. Cambridge Univerisity Press. pp 118-119. 
     */
    public static double[] splineInterpolator(double[] xSeries, double[] ySeries, double[] xSeriesNew) {
        // Calculate the natural spline 
        int ii, kk;
        double p, qn, sig, un;
        int n = ySeries.length;
        double[] y2 = new double[n];
        double[] u = new double[n - 1];
        // natural spline definition sets second derivative at lower boundary to zero 
        y2[0] = 0.0;
        u[0] = 0.0;
        // decomp loop for tridiagonal algorithm, y2 and u are used for temp storage of decomposed factors
        for (ii = 1; ii < n - 1; ii++) {
            sig = (xSeries[ii] - xSeries[ii - 1]) / (xSeries[ii + 1] - xSeries[ii - 1]);
            p = sig * y2[ii - 1] + 2.0;
            y2[ii] = (sig - 1.0) / p;
            u[ii] = (ySeries[ii + 1] - ySeries[ii]) / (xSeries[ii + 1] - xSeries[ii]) - (ySeries[ii] - ySeries[ii - 1]) / (xSeries[ii] - xSeries[ii - 1]);
            u[ii] = (6.0 * u[ii] / (xSeries[ii + 1] - xSeries[ii - 1]) - sig * u[ii - 1]) / p;
        }
        // natural spline definition sets second derivative at upper boundary to zero 
        qn = 0.0;
        un = 0.0;
        y2[n - 1] = (un - qn * u[n - 2]) / (qn * y2[n - 2] + 1.0);
        for (kk = n - 2; kk >= 0; kk--) {
            y2[kk] = y2[kk] * y2[kk + 1] + u[kk];
        }
        // end Calculate the natural spline 
        //
        // Calculate ySeries New values using xSeriesNew and spline parameters 
//TO DO : CHECK IF I NEED TO DO PRE CHECKS OF PRE/POST BOUNDS 
        int nn = xSeriesNew.length;
        double[] ySeriesNew = new double[nn]; // filled with zeros 
        int klo, khi;
        //System.out.println(" klo, khi: " + klo + " , "+ khi);
        double h, b, a;
        //System.out.println("h, b, a: " + h + ", " + b + ", " + a);
        for (ii = 0; ii < nn; ii++) {
            //System.out. println("ii : " + ii) ;
            if (xSeriesNew[ii] < xSeries[0]) {
                //System.out.println( "xSeriesNew[ii] (" + xSeriesNew[ii] + ") < xSeries[0] (" + xSeries[0] + ")"); 
                ySeriesNew[ii] = 0;
            } else if (xSeriesNew[ii] > xSeries[xSeries.length - 1]) {
                //System.out.println("xSeriesNew[ii] (" + xSeriesNew[ii) + ") > xSeries[xSeries.length-1) (" + xSeries[xSeries.length-1) + ")"); 
                ySeriesNew[ii] = 0;
            } else {
                klo = 0; // why doesn't this start at 0? 
                khi = n - 1;
                //System.out.println("klo, khi: "+ klo + " , " + khi);
                //find values of khi and klo that bracket xSeriesNew[ii]
                while (khi - klo > 1) {
                    //System.out.println("khi -klo: " + (khi-klo)); 
                    kk = (khi + klo) >> 1;
                    //System.out.println("kk : " + kk);
                    //System.out.println(" test xSeries[kk] (" + xSeries[kk] + ") > xSeriesNew[ii] (" + xSeriesNew[ii] + ")"); 
                    if (xSeries[kk] > xSeriesNew[ii]) {
                        //System.out.println("TRUE");
                        khi = kk;
                        //System.out.println("khi : "+ khi);
                    } else {
                        klo = kk;
                        //System.out.println(" klo : " + klo); 
                    }
                    //System.out.println("*end of while loop: ii, klo, khi, : " + ii + ", " + klo + ", " + khi); 
                }
                //System.out.println(" xSeries[khi] (" + xSeries[khi] + "), xSer ies[klo] (" + xSeries[klo] + ")");
                h = xSeries[khi] - xSeries[klo];
                //System.out.println("h: " + h); 
                if (h == 0.0) {
                    System.out.println("splint: Bad xSeries input");
                }
                a = (xSeries[khi] - xSeriesNew[ii]) / h;
                b = (xSeriesNew[ii] - xSeries[klo]) / h;
                ySeriesNew[ii] = a * ySeries[klo] + b * ySeries[khi] + ((a * a * a - a) * y2[klo] + (b * b * b - b) * y2[khi]) * (h * h) / 6.0;
            }
        }
        return Arrays.copyOf(ySeriesNew, ySeriesNew.length);
    }
}
