/**
* MODULE NAME:                                          Lightwave
* SOURCE CODE CLASSIFICATION:                           UNCLASSIFIED
* HIGHEST CLASSIFICATION OF INPUT DATA:                 System High
* HIGHEST CLASSIFICATION OF OUTPUT DATA:                System High
* OWNER:                                                23ANS/ANA
* AUTHOR:                                               David Smuck, 23ANS/ANA
* CREATION DATE:                                        07 Oct 2019
*
* PURPOSE:
* This program is the main class for the Lightwave application. It defines
* the FXML and CSS files.
*
* INPUTS:
*
* OUTPUTS:
*
* REVISION HISTORY:
* DATE         MOD-BY        DESCRIPTION
* -----------  ------------  ---------------------------------------------------
* 02 Oct 2019  D. Smuck      Original Version (under the name OPTSIG Viewer)
* 07 Apr 2020  D. Smuck      Initial rehost on an Unclassified system
* 24 Jul 2020  D. Smuck      First Git Version
*
*/
package lightwave;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * @author D. Smuck
 */
public class Lightwave extends Application {
    Stage lightwaveStage = new Stage();
    public boolean isinit = false;
    String version = "0.1.3";
        
    @Override
    public void start(Stage stage) throws Exception {
        Parent lightwaveRoot = FXMLLoader.load(getClass().getResource("Lightwave.fxml"));
        Scene lightwaveScene = new Scene(lightwaveRoot);
        lightwaveScene.getStylesheets().add(getClass().getResource("lightwave.css").toExternalForm());
        lightwaveStage.getIcons().add(new Image(getClass().getResourceAsStream("images/LightwaveIcon20.png")));
        lightwaveStage.setTitle(String.format("Lightwave (Version %s)", version));
        lightwaveStage.setScene(lightwaveScene);
        lightwaveStage.setResizable(false);
        lightwaveStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
