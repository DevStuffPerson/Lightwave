/*
* MODULE NAME:                                   LightwaveFXMLDocumentController
* SOURCE CODE CLASSIFICATION:                    UNCLASSIFIED//FOUO (See Note)
* HIGHEST CLASSIFICATION OF INPUT DATA:          System high
* HIGHEST CLASSIFICATION OF OUTPUT DATA:         System high
* OWNER:                                         23ANS/ANA
* AUTHOR:                                        David Smuck, 23ANS/ANA
* CREATION DATE:                                 02 Oct 2019
*
* PURPOSE:
* This program provides the user interface controls and corresponding logic for
* the Lightwave application.
*
* INPUTS:
*
* OUTPUTS:
*
* NOTE:
* Sensor response weights are FOUO, all other code is UNCLASSIFIED
*
* REVISION HISTORY:
* DATE         MOD-BY       DESCRIPTION
* -----------  -----------  ----------------------------------------------------
* 02 Oct 2019  D. Smuck     Original Version
* 25 Oct 2019  D. Smuck     Added OPTSIG waveform comparison
* 01 Nov 2019  D. Smuck     Added HYCHEM & Query.out waveform support
* 22 Nov 2019  D. Smuck     Added additional sensor weights
* 07 Apr 2020  D. Smuck     Initial rehost on an Unclassified system
* 02 Jun 2020  D. Smuck     Added community HYCHEM and Hinterpol support 
* 03 Jun 2020  D. Smuck     Redesigned waveform list view and selection area
*
 */
package lightwave;

import java.awt.image.RenderedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import java.util.Optional;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.SnapshotParameters;
import javafx.scene.chart.NumberAxis;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import SmeToolsLibrary.LinLogAxis;
import SmeToolsLibrary.LogarithmicAxis;
import SmeToolsLibrary.Waveform;

import static SmeToolsLibrary.WaveformComparison.calculatePcc;
import java.awt.Desktop;
import java.net.URI;
import java.net.URISyntaxException;
import javafx.application.Platform;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.transformation.FilteredList;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import static lightwave.ReadLightwaveFile.readHychemFile;
import static lightwave.ReadLightwaveFile.readCTHFile;
import static lightwave.ReadLightwaveFile.readAndsasOpticalOutFile;
import static lightwave.ReadLightwaveFile.readCSVFile;
import lightwave.SensorOperations.SensorSpectralWeights;
import static lightwave.SensorOperations.loadSensorSpectralWeights;


public class LightwaveFXMLDocumentController implements Initializable {

    /**
     * Declare variables
     */
    // File I/0
    String lightwaveDefaultFileDirectory;
    String SensorSpectralWeightsFileFQN;
    String preferenceFileFQN;
    String lightwaveFile;
    List<File> selectedFiles;
    // CTH- OPTSIG output data descriptors
    String lookAngle;
    String azimuth;
    int nTimes;
    String yield;
    String heightOfBurst;
    String surfaceMaterial;
    // plot defaults
    int choiceBoxXAxisMinIndex = 7;
    int choiceBoxXAxisMaxIndex = 0;
    int choiceBoxYAxisMinIndex = 15;
    int choiceBoxYAxisMaxIndex = 0;
    
    double xAxisLowerBound = -0.5;
    // double xAxisLowerBound = 0.0;
    double xAxisUpperBound = 10000.0;
    double yAxisLowerBound = 1.0;
    double yAxisUpperBound = 1E14;
//    double minXAxis2LowerBound = 1E-7;
//    double maxXAxis2UpperBound = 10.0;
    // Plot legend and CTH-OPTSIG output data descriptor lists
   // List<LightwaveOutput> lightwaveWaveforms = new ArrayList<>();
    ObservableList<String> listMaterial = FXCollections.observableArrayList();
    ObservableList<String> listYield = FXCollections.observableArrayList();
    ObservableList<String> listHOB = FXCollections.observableArrayList();
    ObservableList<String> listLookAngle = FXCollections.observableArrayList();
    ObservableList<String> listBand = FXCollections.observableArrayList();
    ObservableList<LegendObject> observableListLegend = FXCollections.observableArrayList();
    //legendList
    // Reference waveform structures //rev 2
    Waveform lastSelectedWaveform;
    Waveform referenceWaveform;
    boolean compareWaveforms = false;

    List<SensorSpectralWeights> sensorSpectralWeightsList = new ArrayList<>();
    //List<Waveform> waveformList = new ArrayList<>();
    ObservableList<Waveform> waveformList = FXCollections.observableArrayList();
    ObservableList<Waveform> selectedWaveformsList = FXCollections.observableArrayList();
    FilteredList<Waveform> filteredWaveformList = new FilteredList<>(waveformList, b -> true);
    ObservableList<String> selectedMaterialItems = FXCollections.observableArrayList();
    ObservableList<String> selectedYieldItems = FXCollections.observableArrayList();
    ObservableList<String> selectedHOBItems = FXCollections.observableArrayList();
    ObservableList<String> selectedLookAngleItems = FXCollections.observableArrayList();
    ObservableList<String> selectedBandItems = FXCollections.observableArrayList();

    /**
     * Inject FXML objects
     */
    // Banners
    @FXML
    private Text topBanner;
    @FXML
    private Text bottomBanner;
    
    @FXML
    private CheckBox clearFilesCheckBox;
    
// Primary plot: LinLog x-axis, Log y-axis
    @FXML
    private LineChart<?, ?> linechart1;
    @FXML
    private LinLogAxis xAxis1;
    @FXML
    private LogarithmicAxis yAxis1;
// Secondary plot: Log x-axis, Log y-axis
    @FXML
    private LineChart<?, ?> linechart2;
    @FXML
    private LogarithmicAxis xAxis2;
    @FXML
    private LogarithmicAxis yAxis2;
// Third plot: Linear x-axis, Log y-axis
    @FXML
    private LineChart<?, ?> linechart3;
    @FXML
    private NumberAxis xAxis3;
    @FXML
    private LogarithmicAxis yAxis3;
// Filterd list view elements
    @FXML
    private TableView<Waveform> filteredListTableView;
    @FXML
    private TableColumn<Waveform, String> dataSourceColumn;
    @FXML
    private TableColumn<Waveform, String> surfaceMaterialColumn;
    @FXML
    private TableColumn<Waveform, ?> yieldColumn;
    @FXML
    private TableColumn<Waveform, ?> hobColumn;
    @FXML
    private TableColumn<Waveform, ?> lookAngleColumn;
    @FXML
    private TableColumn<Waveform, String> bandSensorColumn;
   
// Plot legend and CTH-OPTSIG output data descriptor scrolable list boxes
    @FXML
    private ListView<String> listViewMaterial;
    @FXML
    private ListView<String> listViewYield;
    @FXML
    private ListView<String> listViewHOB;
    @FXML
    private ListView<String> listViewLookAngle;
    @FXML
    private ListView<String> listViewBand;
    @FXML
    private ListView<LegendObject> listViewLegend;
    // X-axis controls
    @FXML
    private ChoiceBox choiceBoxXAxisMax;
    @FXML
    private ChoiceBox choiceBoxXAxisMin;
// Y-axis controls
    @FXML
    private ChoiceBox choiceBoxYAxisMax;
    @FXML
    private ChoiceBox choiceBoxYAxisMin;
// Plot and legend area saved by saveImage
    @FXML
    private HBox hboxPlotAndLabel;
// Menu item actions

    @FXML
    void handleMenuItemSaveImage(ActionEvent event) {
        saveImage();
    }

    @FXML
    void handleMenuItemSaveConfig(ActionEvent event) {
        saveConfig();
    }

    @FXML
    void handleMenuItemClose(ActionEvent event) {
        Stage lightwaveStage = (Stage) buttonSelectFile.getScene().getWindow();
        lightwaveStage.close();
    }

    @FXML
    void handleMenuItemUnclass(ActionEvent event) {
        ChangeBanner("UNCLASSIFIED");
    }

    @FXML
    void handleMenuItemUnclassFouo(ActionEvent event) {
System.out.println("trying to change to fouo");
        ChangeBanner("UNCLASSIFIED//FOUO");
    }

    @FXML
    void handleMenuItemSecret(ActionEvent event) {
        ChangeBanner("SECRET");
    }

    @FXML
    void handleMenuItemSecretRel(ActionEvent event) {
        ChangeBanner("SECRET//REL TO USA, FVEY");
    }

    @FXML
    void handleMenuItemSecretRD(ActionEvent event) {
        ChangeBanner("SECRET//RD");
    }

    @FXML
    void handleMenuItemNone(ActionEvent event) {
        ChangeBanner("");
    }

    @FXML
    void handleMenuItemAbout(ActionEvent event) throws URISyntaxException, IOException {
        if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
            
            //Desktop.getDesktop().browse(new URI("http://www.cnn.com"));
            //Desktop.getDesktop().browse(new URI("file:\\\\P:\\NetBeansProjects\\Lightwave\\src\\lightwave\\aboutLightwave.html")); 
            //Desktop.getDesktop().open("aboutLightwave.html");
            
            WebView webView = new WebView();
            WebEngine webEngine = webView.getEngine();
            webEngine.load( getClass().getResource("aboutLightwave.html").toString());
            Stage aboutStage = new Stage();
            aboutStage.setScene(new Scene(webView, 1214,600));
            aboutStage.getIcons().add(new Image(getClass().getResourceAsStream("images/LightwaveIcon20.png")));
            aboutStage.setTitle("About Lightwave");
            aboutStage.show();
            
        }
        
        
//          FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource( "searchResultsList.fxml"));
//                Parent rootl = (Parent) fxmlLoader.load();
//                Stage stage = new Stage();
//                stage.setTitle("AWSUM EPRO List");
//                stage.setScene(new Scene(rootl));
//                stage.show(); //stage.showAndWait();
        
    
       
        
        
//        System.out.println("See David Smuck if you have questions... ");
//        Alert alert = new Alert(AlertType.INFORMATION);
//        alert.setTitle("About Lightwave");
//        alert.setHeaderText("Lightwave Information");
//        alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
//        alert.setResizable(true);
//        alert.setContentText("TBD TBD TBD \nLightwave plots the power versus time curves generated by CTH+OPTSIG. Currently only the 15-band output files can be used as input files.Users can select one or more OPTSIG output files(they must be in the s ame directory).The program will parse the file name and contents to ident i f y al l surface materials, yields, heights of burst, look angles, and spectral bands/ sensor responses. Sensor response functions for the standard bhangmeters and AABL are applied to the OPTSIG spectral bands to create additional power versus time curves.The user can select any combination of these input parameters for plotting(standard Shift+click and Ctrl+click behavior appli es).See Mr.David Smuck for questions about the this program.");
//        alert.showAndWait();
    }
// Button actions 
// Select supported waveform file(s) and call parsing subroutine 
    @FXML
    private Button buttonSelectFile;

    @FXML
    void handleButtonSelectFileAction(ActionEvent event) throws FileNotFoundException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Waveform File");
        fileChooser.setInitialDirectory(new File(lightwaveDefaultFileDirectory));
        fileChooser.getExtensionFilters().addAll(new ExtensionFilter("All Files", "*.*"),
                new ExtensionFilter("Hinterpol/CTH OPTSIG Files", "*.dat"),
                new ExtensionFilter("CSV Files", "*.csv"),
                new ExtensionFilter("QUERY Optical Output Files", "*.out"),
                new ExtensionFilter("HYCHEM Files", "*.plt"));
         // File selectedFile = fileChooser.showOpenDialog(null);  //to limit selection to a single file
        selectedFiles = fileChooser.showOpenMultipleDialog(null);
        if (selectedFiles != null) {
            //clear key variables for reuse 
//            lightwaveWaveforms.clear();
            listMaterial.clear();
            listYield.clear();
            listHOB.clear();
            listLookAngle.clear();
            listBand.clear();
            if (clearFilesCheckBox.isSelected()) {
                waveformList.clear();
            }
            loadData();
        } else {
            System.out.println("No valid file selection");
        }
    }
// Plot waveforms based on selected CTH-OPTSIG output data descriptors and Y-axis bounds

    @FXML
    void handleButtonPlotAction(ActionEvent event) {
        
// TO DO: 
//ALSO!!! put the save defaults button and maybe all the stored preferences on this tab!!!!!!!!

// Clear plots and legend 
        observableListLegend.clear();
        linechart1.getData().clear();
        linechart2.getData().clear();
        linechart3.getData().clear();
        // Check the number of waveforms selected 
        int numberWaveformsSelected = selectedWaveformsList.size();
        //int numberWaveformsSelected = selectedMaterialItems.size() * selectedYieldItems.size() * selectedHOBItems.size() * selectedLookAngleItems.size() * selectedBandItems.size();
//System.out.println("You selected " + numberWaveformsSelected + " waveforms..." );
        // Display error if no waveforms are selected 
        if (numberWaveformsSelected == 0) {
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("No Waveforms Selected");
            alert.setHeaderText("No waveforms selected");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.setResizable(true);
            alert.setContentText("Select at least one element from the Filtered List Tab.");
            alert.showAndWait();
        }
        // Display warning if too many waveforms are selected 
        boolean abortPlot = false;
        if (numberWaveformsSelected > 211) {
            long estimatedWaitTime = Math.round(0.00004 * Math.pow(numberWaveformsSelected, 2) - 0.0084 * numberWaveformsSelected + 0.5);
            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Max Waveforms Warning");
            alert.setHeaderText(" You selected " + numberWaveformsSelected + " waveforms!");
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.setResizable(true);
            alert.setContentText(" It may take over " + estimatedWaitTime + " minutes to plot this many waveforms. Do you want to continue and wait or cancel and adjust your selections?");
            ButtonType buttonContinue = new ButtonType("Continue");
            ButtonType buttonCancel = new ButtonType("Cancel");
            alert.getButtonTypes().setAll(buttonContinue, buttonCancel);
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == buttonCancel) {
                abortPlot = true;
            }
        }
        
        
        // Plot waveforms
        if (!abortPlot) {
            int legendIndex = 0;
            Iterator<Waveform> selectedWaveformListIterator = selectedWaveformsList.iterator();
            while(selectedWaveformListIterator.hasNext()) {
                Waveform currentWaveform = selectedWaveformListIterator.next();
                surfaceMaterial = currentWaveform.getSurfaceMaterial();
                yield = String.valueOf(currentWaveform.getYield());
                heightOfBurst = String.valueOf(currentWaveform.getHeightOfBurst());
                lookAngle = String.valueOf(currentWaveform.getLookAngle());
                nTimes = currentWaveform.getNSamples();
//                String band = currentWaveform.getBandLabel();                

                String waveformSeriesName;
                String bandLabel = currentWaveform.getBandLabel();
                // Calculate PCC if reference waveform exists //rev 2
                if (compareWaveforms) {
                    double pcc = calculatePcc(referenceWaveform.getXValues(), referenceWaveform.getYValues(), currentWaveform.getXValues(), currentWaveform.getYValues(), 1, referenceWaveform.getNSamples(), "Reference waveform > 0");
                    waveformSeriesName = surfaceMaterial + ", " + yield + "t, " + heightOfBurst + "m, " + lookAngle + "\u00B0, " + bandLabel + String.format(", %.4f PCC", pcc);
                } else {
                    waveformSeriesName = surfaceMaterial + ", " + yield + "t, " + heightOfBurst + "m, " + lookAngle + "\u00B0, " + bandLabel;
                } // Calculate PCC
                XYChart.Series waveformSeries = new XYChart.Series();
                XYChart.Series waveformSeries2 = new XYChart.Series();
                XYChart.Series waveformSeries3 = new XYChart.Series();
                double[] xSeries = currentWaveform.getXValues();
                double[] ySeries = currentWaveform.getYValues();
                observableListLegend.add(new LegendObject(waveformSeriesName, legendIndex));
                legendIndex++;
                for (int ii = 0; ii < nTimes; ii++) {
                    //if current time step cannot be plotted on log scale(ie zero) add a small delta for secondary plot
// is this needed if the plot axis range logic prevents <= 0?
                    if (xSeries[ii] <= 0) {
                        waveformSeries2.getData().add(new XYChart.Data(xSeries[ii] + 1E-12, ySeries[ii]));
                    } else {
                        waveformSeries2.getData().add(new XYChart.Data(xSeries[ii], ySeries[ii]));
                    }
                    // convert the times from seconds to milliseconds for lin-log plot 
                    waveformSeries.getData().add(new XYChart.Data(xSeries[ii] * 1000, ySeries[ii]));
                    waveformSeries3.getData().add(new XYChart.Data(xSeries[ii], ySeries[ii]));
                }
                waveformSeries.setName(waveformSeriesName);
                linechart1.getData().add(waveformSeries);
                linechart2.getData().add(waveformSeries2);
                linechart3.getData().add(waveformSeries3);
//next line to change with new select reference waveform method
                lastSelectedWaveform = currentWaveform;
            } // End iterate through waveforms 
            // Build legend 
            listViewLegend.setCellFactory((ListView<LegendObject> p) -> {
                ListCell<LegendObject> cell = new ListCell<LegendObject>() {
                    @Override
                    protected void updateItem(LegendObject lo, boolean bln) {
                        super.updateItem(lo, bln);
                        if (lo != null) {
                            setGraphic(createSymbol(lo.getSeriesIndex()));
                            setText(lo.getSeriesName());
                        }
                    }
                };
                return cell;
            });
            updateAxes();
//next 6 lines to change with new select reference waveform method
            // Activate Set Reference Waveform button when only one waveform is displayed //rev 2 
            if (observableListLegend.size() == 1) {
                buttonSetRefWF.setDisable(false);
            } else {
                buttonSetRefWF.setDisable(true);
            }
        }//end !abortPlot 
    } //end handleButtonPlotAction
    
    // Set reference waveform for comparison //rev 2 
    @FXML private Button buttonSetRefWF;

    @FXML
    void handleButtonSetRefWFAction(ActionEvent event) {
        buttonClearRefWF.setDisable(false);
        referenceWaveform = lastSelectedWaveform;
        compareWaveforms = true;
//        System.out.println(" referenceWaveform.azimuth: " + referenceWaveform.azimuth);
//        System.out.println(" referenceWaveform.band: " + referenceWaveform.band);
//        System.out.println(" referenceWaveform.bandLabel: " + referenceWaveform.bandLabel);
//        System.out.println(" referenceWaveform.heightOfBurst : " + referenceWaveform.heightOfBurst);
//        System.out.println(" referenceWaveform.lookAngle: " + referenceWaveform.lookAngle);
//        System.out.println(" referenceWaveform.surfaceMaterial: " + referenceWaveform.surfaceMaterial);
//        System.out.println(" referenceWaveform.yield: " + referenceWaveform.yield);
//        System.out.println(" referenceWaveform.nTimes : " + referenceWaveform.nSamples);
//        System.out.println(" referenceWaveform.power : " + Arrays.toString(referenceWaveform.getYValues()));
//        System.out.println(" referenceWaveform.times : " + Arrays.toString(referenceWaveform.getXValues()));
    }
    
    // Clear reference waveform for comparison //rev 2 
    @FXML private Button buttonClearRefWF;

    @FXML
    void handleButtonClearRefWFAction(ActionEvent event) {
        buttonClearRefWF.setDisable(true);
        compareWaveforms = false;
    }

    /**
     * Save current plot to file
     */
    private void saveImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Image");
        fileChooser.setInitialDirectory(new File(lightwaveDefaultFileDirectory));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("png files(*.png) ", "*.png"));
        File selectedFile = fileChooser.showSaveDialog(null);
        if (!selectedFile.getAbsolutePath().endsWith(". png")) {
            selectedFile = new File(selectedFile.getAbsolutePath());
        }
        try {
            WritableImage writableImage = hboxPlotAndLabel.snapshot(new SnapshotParameters(), null);
            RenderedImage renderedImage = SwingFXUtils.fromFXImage(writableImage, null);
            ImageIO.write(renderedImage, "png", selectedFile);
        } catch (IOException ex) {
        }
    }

    /*
     * Change the displayed banner to:
     * @param banner
     */
    private void ChangeBanner(String bannerText) {
        //String bannerText = banner;
        topBanner.setText(bannerText);
        bottomBanner.setText(bannerText);
        if (bannerText.length() >= 6 && (bannerText.substring(0, 6)).equals("SECRET")) {
            topBanner.setFill(Color.RED);
            bottomBanner.setFill(Color.RED);
        } else if (bannerText.length() >= 6 && (bannerText.substring(0, 6)).equals("UNCLAS")) {
            topBanner.setFill(Color.GREEN);
            bottomBanner.setFill(Color.GREEN);
        }
    }

    
    /*
     * Logic to load and parse data from CTH - OPTSIG, HYCHEM, CSV, Hinterpol, and ANDSAS Optical output data files
     * TO DO: 
     */
    private void loadData() throws FileNotFoundException {
        // iterate through all selected files 
        for (int fileIndex = 0; fileIndex < selectedFiles.size(); fileIndex++) {
            lightwaveFile = selectedFiles.get(fileIndex).getAbsolutePath();
            lightwaveDefaultFileDirectory = selectedFiles.get(fileIndex).getParent();
            String fileName = selectedFiles.get(fileIndex).getName();
            String fileExtension = fileName.substring(fileName.lastIndexOf("."), fileName.length());
             if (null != fileExtension) switch (fileExtension) {
                case ".dat":
                case ".DAT":
                    // This is used for CHT/OPTSIG and Hinterpol
                    waveformList.addAll(readCTHFile(lightwaveFile, sensorSpectralWeightsList));
                    break;
                case ".PLT":
                case ".plt":
                    waveformList.addAll(readHychemFile(lightwaveFile, sensorSpectralWeightsList));
                    break;
                case ".out":
                case ".OUT":
                    waveformList.addAll(readAndsasOpticalOutFile(lightwaveFile));
                    // set banner to secret if not already set at or higher using assumption that .out file contains operational satellite data 
                    if (topBanner.getText().length() == 0 || !topBanner.getText().substring(0, 6).equals("SECRET")) {
                        ChangeBanner("SECRET");
                    }
                    break;
                case ".csv":
                case ".CSV":
                    waveformList.addAll(readCSVFile(lightwaveFile));
                    break;
                default:
                    System.out.println("WARNING: Unknown file type in " + fileName);
                    break;
            }
        } // end of selectedFiles loop 

        // build selection lists
            for (Iterator<Waveform> it = waveformList.iterator(); it.hasNext();) {
                Waveform currentWaveform = it.next();
                if (!listMaterial.contains(currentWaveform.getSurfaceMaterial())) {
                    listMaterial.add(currentWaveform.getSurfaceMaterial());
                }
                if (!listYield.contains(String.valueOf(currentWaveform.getYield()))) {
                    listYield.add(String.valueOf(currentWaveform.getYield()));
                }
                if (!listHOB.contains(String.valueOf(currentWaveform.getHeightOfBurst()))) {
                    listHOB.add(String.valueOf(currentWaveform.getHeightOfBurst()));
                }
                if (!listLookAngle.contains(String.valueOf(currentWaveform.getLookAngle()))) {
                    listLookAngle.add(String.valueOf(currentWaveform.getLookAngle()));
                }
                if (!listBand.contains(currentWaveform.getBandLabel())) {
                    listBand.add(currentWaveform.getBandLabel());
                }
            }
        // Select fist element in each field except band/sensor where bdye is selected 
        listViewMaterial.getSelectionModel().selectAll();// .selectFirst();
        listViewYield.getSelectionModel().selectAll();// .selectFirst();
        listViewHOB.getSelectionModel().selectAll();// .selectFirst();
        listViewLookAngle.getSelectionModel().selectAll();// .selectFirst();
        //listViewBand.getSelectionModel().selectAll();// .selectIndices(4); //TO DO: actually search for and select index for bdye_f or bdye3, or silicon if neither exist
        ObservableList<String> tempBandList = listViewBand.getItems();
        if (tempBandList.indexOf("BDYE IIF") >= 0) {
            listViewBand.getSelectionModel().selectIndices(tempBandList.indexOf("BDYE IIF"));
        } else if (tempBandList.indexOf("IIF Power") >= 0) {
            listViewBand.getSelectionModel().selectIndices(tempBandList.indexOf("IIF Power"));
        } else if (tempBandList.indexOf("Si POWER") >= 0) {
            listViewBand.getSelectionModel().selectIndices(tempBandList.indexOf("Si POWER"));
        } else if (tempBandList.indexOf("Silicon") >= 0) {
            listViewBand.getSelectionModel().selectIndices(tempBandList.indexOf("Silicon"));
        } else {
            listViewBand.getSelectionModel().selectAll();
        }
    }   
             
    
    
    
    private void saveConfig() {
        System.out.println("Saving the user preference xml file");
        try {
            //File xmlPreferenceFile = new File(preferenceFileFQN); //CAN THIS BE DELETED? 
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document userPrefs = builder.newDocument();
            Element rootElement = userPrefs.createElement("config");
            userPrefs.appendChild(rootElement);
//
            Element defaultDirectory = userPrefs.createElement("defaultFileDirectory");
            defaultDirectory.appendChild(userPrefs.createTextNode(lightwaveDefaultFileDirectory));
            rootElement.appendChild(defaultDirectory);
//
            Element defaultYAxisMin = userPrefs.createElement("defaultYAxisMinIndex");
            choiceBoxYAxisMinIndex = choiceBoxYAxisMin.getSelectionModel().getSelectedIndex();
            defaultYAxisMin.appendChild(userPrefs.createTextNode(String.valueOf(choiceBoxYAxisMinIndex)));
            rootElement.appendChild(defaultYAxisMin);
//
            Element defaultYAxisMax = userPrefs.createElement("defaultYAxisMaxIndex");
            choiceBoxYAxisMaxIndex = choiceBoxYAxisMax.getSelectionModel().getSelectedIndex();
            defaultYAxisMax.appendChild(userPrefs.createTextNode(String.valueOf(choiceBoxYAxisMaxIndex)));
            rootElement.appendChild(defaultYAxisMax);
// write the contents into xml file 
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(userPrefs);
            StreamResult result = new StreamResult(new File(preferenceFileFQN));
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source, result);
        } catch (IllegalArgumentException | ParserConfigurationException | TransformerException | DOMException e) {
        }
    }

    private void updateFilteredWaveformListPredicate() {
        filteredWaveformList.setPredicate(s -> 
                selectedMaterialItems.contains(s.getSurfaceMaterial()) && 
                selectedYieldItems.contains(String.valueOf(s.getYield())) &&
                selectedHOBItems.contains(String.valueOf(s.getHeightOfBurst())) &&
                selectedLookAngleItems.contains(String.valueOf(s.getLookAngle())) &&
                selectedBandItems.contains(s.getBandLabel()) );
        filteredListTableView.getSelectionModel().selectAll();
    }

    private double returnAxisValue(String value) {
        // This function returns the numeric value used by the plot axes for a passed string
        switch (value) {
            case "-0.5": return -0.5;
            case "0": return 0;
            case "0.5": return 0.5;
            case "1": return 1;
            case "10": return 10;
            case "10\u00B2": return 100;
            case "10\u00B3": return 1000;
            case "10\u2074": return 10000;
            case "10\u2075": return 100000; 
            case "10\u2076": return 1000000;
            case "10\u2077": return 10000000;
            case "10\u2078": return 100000000;
            case "10\u2079": return 1000000000;
            case "10\u00B9\u2070": return 1E10;
            case "10\u00B9\u00B9": return 1E11;
            case "10\u00B9\u00B2": return 1E12;
            case "10\u00B9\u00B3": return 1E13;
            case "10\u00B9\u2074": return 1E14;
            case "10\u00B9\u2075": return 1E15;
            }
            System.out.println("WARNING!!! YOU DIDN'T MATCH A SELECTION IN THE returnAxisValue function");
        return 0;
    }

    private String returnAxisString(double value) {
        // This function returns the formatted string used in the axis choiceboxes for a passed value
        // the switch approach doesn't work with all values.  Better alternatives welcome.  Similar issue exists in the logarithmic axis class.
        if (value == 0) {
            return "0";
        } else if (Math.round(value*10) == 5) {
            return "0.5";
        } else if (Math.round(value*10) == -5) {
            return "-0.5";
        }
        switch ((int) Math.round(value)) {
            case 1:
                return "1";
            case 10:
                return "10";
            case 100:
                return "10\u00B2";
            case 1000:
                return "10\u00B3";
            case 10000:
                return "10\u2074";
            case 100000:
                return "10\u2075";
            case 1000000:
                return "10\u2076";
            case 10000000:
                return "10\u2077";
            case 100000000:
                return "10\u2078";
            case 1000000000:
                return "10\u2079";
        }
        if (value > 1E-8 && value < 1E-6){
            return "10\u207B\u2077";
        } else if (value > 1E-7 && value < 1E-5) {
            return "10\u207B\u2076";
        } else if (value > 1E-6 && value < 1E-4) {
            return "10\u207B\u2075";
        } else if (value > 1E-5 && value < 1E-3) {
            return "10\u207B\u2074";
        } else if (value > 1E-4 && value < 1E-2) {
            return "10\u207B\u00B3";
        } else if (value > 1E-3 && value < 1E-1) {
            return "10\u207B\u00B2";
        } else if (value > 1E-2 && value < 1) {
            return "10\u207B\u00B9";
        } else if (value > 1E9 && value < 1E11) {
            return "10\u00B9\u2070";
        } else if (value > 1E10 && value < 1E12) {
            return "10\u00B9\u00B9";
        } else if (value > 1E11 && value < 1E13) {
            return "10\u00B9\u00B2";
        } else if (value > 1E12 && value < 1E14) {
            return "10\u00B9\u00B3";
        } else if (value > 1E13 && value < 1E15) {
            return "10\u00B9\u2074";
        } else if (value > 1E14 && value < 1E16) {
            return "10\u00B9\u2075";
        }
        System.out.println("WARNING!!! YOU DIDN'T MATCH A SELECTION IN THE returnAxisString function");
        return "0";
    }
    
    private void updateAxes() {
        // This function redraws all plots
        // Update x Axis with current min/max values
        // Plot 1 has a lin/log x axis so negative numbers are ok, 
        // Plot 2 has a log x axis so values =< 0 are invalid and a small number is used instead
        // Plot 3 has a linear x axis so negative numbers are ok but the scale is in seconds, not ms so the limit is adjusted by 1000
        xAxis1.setLowerBound(xAxisLowerBound);
        if (xAxisLowerBound <= 0.0) {
            xAxis2.setLowerBound(1E-7);
        } else {
            xAxis2.setLowerBound(xAxisLowerBound/1000);
        }
        xAxis3.setLowerBound(xAxisLowerBound/1000);
        xAxis1.setUpperBound(xAxisUpperBound);
        if (xAxisUpperBound <= 0) {
            xAxis2.setUpperBound(1E-7);
        } else {
            xAxis2.setUpperBound(xAxisUpperBound/1000);
        }    
        xAxis3.setUpperBound(xAxisUpperBound/1000);
        // Update y Axis with current min/max values
        yAxis1.setLowerBound(yAxisLowerBound);
        yAxis2.setLowerBound(yAxisLowerBound);
        yAxis3.setLowerBound(yAxisLowerBound);
        yAxis1.setUpperBound(yAxisUpperBound);
        yAxis2.setUpperBound(yAxisUpperBound);
        yAxis3.setUpperBound(yAxisUpperBound);
    }

    private void loadXmlPreferenceFile() {
        try {
            File xmlPreferenceFile = new File(preferenceFileFQN);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            // Check if preference file exists and create it if it doesn't 
            if (!xmlPreferenceFile.exists()) {
                System.out.println("User preference xml file does NOT exist... creating it!");
                File directory = new File(lightwaveDefaultFileDirectory);
                if (!directory.exists()) {
                    System.out.println(" " + lightwaveDefaultFileDirectory + " directory does not exits... creating it.");
                    directory.mkdir();
                //on windows, this this assumes the home directory
                }
                Document userPrefs = builder.newDocument();
                Element rootElement = userPrefs.createElement("config");
                userPrefs.appendChild(rootElement);

                Element defaultDirectory = userPrefs.createElement("defaultFileDirectory");
                defaultDirectory.appendChild(userPrefs.createTextNode(lightwaveDefaultFileDirectory));
                rootElement.appendChild(defaultDirectory);

                Element defaultYAxisMin = userPrefs.createElement("defaultYAxisMinIndex");
                defaultYAxisMin.appendChild(userPrefs.createTextNode("l4"));
                rootElement.appendChild(defaultYAxisMin);

                Element defaultYAxisMax = userPrefs.createElement("defaultYAxisMaxIndex");
                defaultYAxisMax.appendChild(userPrefs.createTextNode("l"));
                rootElement.appendChild(defaultYAxisMax);
                // write the contents into xml file 
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                Transformer transformer = transformerFactory.newTransformer();
                DOMSource source = new DOMSource(userPrefs);
                StreamResult result = new StreamResult(new File(preferenceFileFQN));
                transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                transformer.transform(source, result);
            }
            // Read from the preference file and apply contents 
            Document userPrefs = builder.parse(xmlPreferenceFile);
            userPrefs.getDocumentElement().normalize();//what does this do? 
            NodeList nList = userPrefs.getElementsByTagName("config");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                org.w3c.dom.Node nNode = nList.item(temp);
                if (nNode.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    lightwaveDefaultFileDirectory = eElement.getElementsByTagName("defaultFileDirectory").item(0).getTextContent();
                    choiceBoxYAxisMinIndex = Integer.parseInt(eElement.getElementsByTagName("defaultYAxisMinIndex").item(0).getTextContent());
                    choiceBoxYAxisMaxIndex = Integer.parseInt(eElement.getElementsByTagName("defaultYAxisMaxIndex").item(0).getTextContent());
                }
            }
        } catch (IOException | IllegalArgumentException | ParserConfigurationException | TransformerException | DOMException | SAXException e) {
        }
    }
    
    @FXML
    void handleButtonLoadXmlPreferenceFile(ActionEvent event) {
        loadXmlPreferenceFile();
        choiceBoxYAxisMax.getSelectionModel().select(choiceBoxYAxisMaxIndex);
        choiceBoxYAxisMin.getSelectionModel().select(choiceBoxYAxisMinIndex);
    }
    
    @FXML
    void handlebuttonExpandAxisRange(ActionEvent event) {
        choiceBoxXAxisMax.getSelectionModel().select(0);
        choiceBoxXAxisMin.getSelectionModel().select(choiceBoxXAxisMax.getItems().size()-1);
        choiceBoxYAxisMax.getSelectionModel().select(0);
        choiceBoxYAxisMin.getSelectionModel().select(choiceBoxYAxisMax.getItems().size()-1);
    }


    /**
     * Custom object to store waveform names in the plot legend
     */
    class LegendObject {
        String seriesName;
        int seriesIndex;
        LegendObject(String name, int Index) {
            seriesName = name;
            seriesIndex = Index;
        }
        String getSeriesName() {
            return seriesName;
        }
        int getSeriesIndex() {
            return seriesIndex;
        }
    }

    /**
     * Method to create colored symbol for each item in the legend
     */
    private Node createSymbol(int seriesIndex) {
        Node symbol = new StackPane();
        symbol.getStyleClass().setAll("chart-line-symbol", "series" + seriesIndex, "default-color" + (seriesIndex % 8));
        return symbol;
    }

    
    
    
    
    /**
     * Initialization of Lightwave with default parameters
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Check OS to determine proper default directory/input file(s)
        if (System.getProperty("os.name").equals("Linux") || System.getProperty("os.name").equals("Mac OS X")) {
            lightwaveDefaultFileDirectory = System.getProperty("user.home") + "/lightwave";
            preferenceFileFQN = lightwaveDefaultFileDirectory.concat("/lightwaveprefs.xml");
            SensorSpectralWeightsFileFQN = lightwaveDefaultFileDirectory.concat("/sensorspectralweights.csv");
        } else {            
            lightwaveDefaultFileDirectory = String.format("%s\\Documents\\lightwave", System.getProperty("user.home"));
            preferenceFileFQN = lightwaveDefaultFileDirectory.concat("\\lightwaveprefs.xml");
            SensorSpectralWeightsFileFQN = lightwaveDefaultFileDirectory.concat("\\sensorspectralweights.csv");
        }
        // Load/create preference file
        loadXmlPreferenceFile();
        
        // Load saved or generic sensor specific spectral weights
        sensorSpectralWeightsList = loadSensorSpectralWeights(SensorSpectralWeightsFileFQN);

        // Set default reference waveform button states
        buttonSetRefWF.setDisable(true);
        buttonClearRefWF.setDisable(true);

        // Set allowed values for the x-Axis bound selectors
        String xAxisValues[] = {
            "10\u2074",
            "10\u00B3",
            "10\u00B2",
            "10",
            "1",
            "0.5",
            "0",
            "-0.5"
        };
        // Set allowed values for the y-Axis bound selectors
        String yAxisValues[] = {
            "10\u00B9\u2075",
            "10\u00B9\u2074",
            "10\u00B9\u00B3",
            "10\u00B9\u00B2",
            "10\u00B9\u00B9",
            "10\u00B9\u2070",
            "10\u2079",
            "10\u2078",
            "10\u2077",
            "10\u2076",
            "10\u2075",
            "10\u2074",
            "10\u00B3",
            "10\u00B2",
            "10",
            "1"
        };

        // Add allowed values to axis bounds choiceboxes
        choiceBoxXAxisMax.setItems(FXCollections.observableArrayList(xAxisValues));
        choiceBoxXAxisMin.setItems(FXCollections.observableArrayList(xAxisValues));
        choiceBoxYAxisMax.setItems(FXCollections.observableArrayList(yAxisValues));
        choiceBoxYAxisMin.setItems(FXCollections.observableArrayList(yAxisValues));
        

        // Add Listeners for the axis bounds choiceboxes
        // Each contains logic to prevent an illogical selection of a min>max or max<min
        choiceBoxXAxisMax.getSelectionModel().selectedItemProperty().addListener((obs , oldValue, newValue) -> { 
            double tempXAxisUpperBound = returnAxisValue(newValue.toString());
            if (tempXAxisUpperBound > xAxisLowerBound) {
                xAxisUpperBound = tempXAxisUpperBound;
                updateAxes();
            } else {
                System.out.println("Your selected max x axis value must be greater than the current minimum");
                choiceBoxXAxisMax.setValue(oldValue);
            }
        }) ;       
        
        choiceBoxXAxisMin.getSelectionModel().selectedItemProperty().addListener((obs , oldValue, newValue) -> { 
            double tempXAxisLowerBound = returnAxisValue(newValue.toString());
            if (tempXAxisLowerBound < xAxisUpperBound) {
                xAxisLowerBound = tempXAxisLowerBound;
                updateAxes();
            } else {
                System.out.println("Your selected min x axis value must be lower than the current maximum");
                choiceBoxXAxisMin.setValue(oldValue);
            }
        }) ; 
        
        choiceBoxYAxisMax.getSelectionModel().selectedItemProperty().addListener((obs , oldValue, newValue) -> { 
            double tempYAxisUpperBound = returnAxisValue(newValue.toString());
            if (tempYAxisUpperBound > yAxisLowerBound) {
                yAxisUpperBound = tempYAxisUpperBound;
                updateAxes();
            } else {
                System.out.println("Your selected max y axis value must be greater than the current minimum");
                choiceBoxYAxisMax.setValue(oldValue);
            }
        }) ; 
        
        choiceBoxYAxisMin.getSelectionModel().selectedItemProperty().addListener((obs , oldValue, newValue) -> { 
            double tempYAxisLowerBound = returnAxisValue(newValue.toString());
            if (tempYAxisLowerBound < yAxisUpperBound) {
                yAxisLowerBound = tempYAxisLowerBound;
                updateAxes();
            } else {
                System.out.println("Your selected min x axis value must be lower than the current maximum");
                choiceBoxYAxisMin.setValue(oldValue);
            }
        }) ; 

        // Set the current axis bounds in the choiceboxes (x comes from variable defn and y comes from xml preference file)
        choiceBoxXAxisMax.setValue(returnAxisString(xAxisUpperBound));
        choiceBoxXAxisMin.setValue(returnAxisString(xAxisLowerBound));
        // Current xml method stores/loads the index, not the value...that shoudl change to storing the numerical value
//        choiceBoxYAxisMax.setValue(returnAxisString(yAxisUpperBound));
//        choiceBoxYAxisMin.setValue(returnAxisString(yAxisLowerBound));
        choiceBoxYAxisMax.getSelectionModel().select(choiceBoxYAxisMaxIndex);
        choiceBoxYAxisMin.getSelectionModel().select(choiceBoxYAxisMinIndex);
        
        
        // link filtered list columns to their contents
        dataSourceColumn.setCellValueFactory(new PropertyValueFactory<>("dataSource")); //name of the origin file for this waveform
        surfaceMaterialColumn.setCellValueFactory(new PropertyValueFactory<>("surfaceMaterial"));
        yieldColumn.setCellValueFactory(new PropertyValueFactory<>("yield"));
        hobColumn.setCellValueFactory(new PropertyValueFactory<>("heightOfBurst"));
        lookAngleColumn.setCellValueFactory(new PropertyValueFactory<>("lookAngle"));
        bandSensorColumn.setCellValueFactory(new PropertyValueFactory<>("bandLabel"));
        filteredListTableView.setItems(filteredWaveformList);
        filteredListTableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        filteredListTableView.getSelectionModel().getSelectedItems().addListener((ListChangeListener.Change<? extends Waveform> changed) -> {
            selectedWaveformsList = filteredListTableView.getSelectionModel().getSelectedItems();
        });
        // link descriptor list boxes to their contents 
        listViewMaterial.setItems(listMaterial.sorted());
        listViewYield.setItems(listYield.sorted());
        listViewHOB.setItems(listHOB.sorted());
        listViewLookAngle.setItems(listLookAngle.sorted());
        listViewBand.setItems(listBand.sorted());
        //listViewBand.setItems(listBand);
        listViewLegend.setItems(observableListLegend);
        listViewMaterial.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        listViewYield.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        listViewHOB.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        listViewLookAngle.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        listViewBand.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        // add listeners
        ////next 4 lines work in most cases but not when deselecting items with ctrl+mouse click
        //listViewMaterial.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
        //selectedMaterialItems = listViewMaterial.getSelectionModel().getSelectedItems();
        //System.out.println("selectedMaterialItems = " + selectedMaterialItems);
        //});
        listViewMaterial.getSelectionModel().getSelectedItems().addListener((ListChangeListener.Change<? extends String> changed) -> {
            selectedMaterialItems = listViewMaterial.getSelectionModel().getSelectedItems();
            updateFilteredWaveformListPredicate();
            //  Platform.runLater(() -> {      }); //not sure if this is useful
            });
        listViewYield.getSelectionModel().getSelectedItems().addListener((ListChangeListener.Change<? extends String> changed) -> {
            selectedYieldItems = listViewYield.getSelectionModel().getSelectedItems();
            updateFilteredWaveformListPredicate();
            });
        listViewHOB.getSelectionModel().getSelectedItems().addListener((ListChangeListener.Change<? extends String> changed) -> {
            selectedHOBItems = listViewHOB.getSelectionModel().getSelectedItems();
            updateFilteredWaveformListPredicate();
            });
        listViewLookAngle.getSelectionModel().getSelectedItems().addListener((ListChangeListener.Change<? extends String> changed) -> {
            selectedLookAngleItems = listViewLookAngle.getSelectionModel().getSelectedItems();
            updateFilteredWaveformListPredicate();
            });
        listViewBand.getSelectionModel().getSelectedItems().addListener((ListChangeListener.Change<? extends String> changed) -> {
            selectedBandItems = listViewBand.getSelectionModel().getSelectedItems();
            updateFilteredWaveformListPredicate();
            });        
        
        // configure primary chart 
        linechart1.setCreateSymbols(false);
        linechart1.setAnimated(false);
        linechart1.setLegendVisible(false);
        xAxis1.setLabel("Time (milliseconds)");
        yAxis1.setLabel("Power (W)");
        // configure secondary chart 
        linechart2.setCreateSymbols(false);
        linechart2.setAnimated(false);
        linechart2.setLegendVisible(false);
        xAxis2.setLabel("Time (seconds)");
        yAxis2.setLabel("Power (W)");
        // configure third chart 
        linechart3.setCreateSymbols(false);
        linechart3.setAnimated(false);
        linechart3.setLegendVisible(false);
        xAxis3.setAutoRanging(false);
        xAxis3.setTickUnit(1);
        xAxis3.setLabel("Time (seconds)");
        yAxis3.setLabel("Power (W)");
        updateAxes(); // is this needed?
        
        // set default banner 
        ChangeBanner("UNCLASSIFIED//FOUO");
        
        

        
    } // end initialize
}
