/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lightwave;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import SmeToolsLibrary.Waveform;

/**
 *
 * @author David Smuck 
 */
public class ReadLightwaveFile {
    
    public static List<Waveform> readHychemFile(String lightwaveFile, List<SensorOperations.SensorSpectralWeights> sensorSpectralWeightsList) throws FileNotFoundException  {
        /* This function reads HYCHEM files.  Two formats are supporeted:
         * 1) Community HYCHEM Version 2013a.0
         * 2) Sn Hychem (version unknown at this time, circa 2019)
         *
         *
         * The community HYCHEM Version 2013a.0 has the following format:
         * It assumes the data section includes columns for time, Si, S4,  
         * Thermal, and 16 spectral bands.
         * Lines 1-5 contain the version and run time
         * Line 6 is blank
         * Line 7 has a title (which doesn't seem to change)
         * Lines 8-11 contain the column headings for the data
         * Lines 12-13 are blank
         * Line 14 contains the yield, altitude, and mass inputs for the sim
         * Line 15 is blank
         * Lines 16 and on are the data which appear to be in fixed width columns
         * An example is shown below:
         *#####################################################################################
         *#HYCHEM VER:  2013a.0                             GIT VER:                           
         *#####################################################################################
         *#BUILD DATE:  Fri Apr  3 11:44:29 MDT 2020       
         *#####################################################################################
         *
         * TITLE = "RAD PWR"
         * VARIABLES = "Time (sec)", "Power_Si (W)", "Power_S4 (W)", "THERMAL (W)", 
         * * "Band 1", "Band 2", "Band 3", "Band 4", "Band 5", "Band 6", 
         * "Band 7", "Band 8", "Band 9", "Band 10", "Band 11", "Band 12", 
         * "Band 13", "Band 14", "Band 15", "Band 16"
         *  
         *
         *#   TOGLR 1000.00KT  2.16KM   999kg (AUTO)                                         
         *
         *0.0000E+00  5.2223E+12  1.9065E+13  7.4883E+13  1.0868E+10  1.9454E+10  3.4823E+10  6.2334E+10  1.1158E+11  1.9972E+11  3.5749E+11  6.3989E+11  1.1454E+12  2.0501E+12  3.6693E+12  6.5672E+12  1.1754E+13  2.1035E+13  2.7226E+13  1.9323E-38
         *...
         * 
         * 
         * The SnHychem has the following format:
         * Line 1 is blank
         * Line 2 contains the input yield, HOB, mass, ICHEM and DRCONZN values
         * Line 3 is blank
         * Line 4 contains the number of time points
         * Line 5 states Power Values are in Watts
         * Line 6 contains the column headings (time + Bands 1-16)
         * Lines 7 and on are the data which appear to be in fixed width columns
         * An example is shown below:
         * 
         * Y(kt)=   3.000,  HOB(km)=30.00,  M(kg)=   26.5,  ICHEM=0,  DRCONZN0.2000
         *
         *   155 = # of points
         * Power Values are in W
         * Time (s)     Band  1     Band  2     Band  3     Band  4     Band  5     Band  6     Band  7     Band  8     Band  9     Band 10     Band 11     Band 12     Band 13     Band 14     Band 15     Band 16
         *0.0000E+00  1.1978E+11  4.3606E+11  1.9186E+12  2.5041E+08  4.4816E+08  8.0203E+08  1.4352E+09  2.5682E+09  4.5952E+09  8.2211E+09  1.4706E+10  2.6304E+10  4.7038E+10  8.4100E+10  1.5032E+11  2.6861E+11
         *... 
         * 
         * 
         * 
         * TO DO: 
         * 
         */
        
        String line;
        double yield = 0.0;
        double heightOfBurst = 0.0;
        double mass = 0.0;
        String surfaceMaterial = "Free Air";
        String[] bandLabels = {};
        int nColumns = 0;
        int spectralBandsColumnOffset = 0;
        List<Waveform> waveformList = new ArrayList<>();
        List<List<Double>> dataArray = new ArrayList<>();
        // Build pattern matchers
        Pattern patternCommunityHychemHeader = Pattern.compile("#HYCHEM VER:  2013a");
        Pattern patternSnHychemHeader = Pattern.compile("=(.*?),\\s+HOB\\(km\\)=(.*?),\\s+M\\(kg\\)=(.*?),");//matcherFileHeader.group(3) , mass , is not used at this time
        //boolean communityHychem = false;
        //boolean snHychem = false;
        // open the current file and read the data 
        try (FileReader fileReader = new FileReader(lightwaveFile)) {
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            // read and parse the file one line at a time 
            int lineNumber = 0;
            bufferedReader.readLine();
            lineNumber++;
            line = bufferedReader.readLine();
            lineNumber++;
            Matcher matcherCommunityHychemHeader = patternCommunityHychemHeader.matcher(line);
            Matcher matcherSnHychemHeader = patternSnHychemHeader.matcher(line);
            if (matcherCommunityHychemHeader.find()) {
                //communityHychem = true;
                nColumns = 20;
                spectralBandsColumnOffset = 3;
                bandLabels = new String[]{"Power_Si (W)", "Power_S4 (W)", "THERMAL (W)",
                    "Band 01", "Band 02", "Band 03", "Band 04", "Band 05", "Band 06", 
                    "Band 07", "Band 08", "Band 09", "Band 10", "Band 11", "Band 12", 
                    "Band 13", "Band 14", "Band 15", "Band 16"};
                while ((line = bufferedReader.readLine()) != null) {
                    lineNumber++;
                    if (lineNumber == 14) {
                        Pattern patternSimulationHeader = Pattern.compile("#   TOGLR\\s+(\\d+\\.?\\d*)KT\\s+(\\d+\\.?\\d*)KM\\s+(\\d+\\.?\\d*)kg");
                        /* Decoding the pattern above:  
                         * () surround the value to be captured in a group
                         * \\d is a digit
                         * \\s is any white space character
                         * \\. Is a period (just a . is any character)
                         * + means one or more
                         * ? means once or not at all
                         * * means zero or more times
                         * For example:  
                         * #   TOGLR\\s+ looks for the characters “#   TOGLR” followed by any white space
                         * (\\d+\\.?\\d*) captures one or more digit followed by one or no . followed by zero or more digits
                         * For more, see: https://docs.oracle.com/javase/7/docs/api/java/util/regex/Pattern.html 
                        */
                        Matcher matcherSimulationHeader = patternSimulationHeader.matcher(line);
                        if (matcherSimulationHeader.find()) {
                            yield = Double.valueOf(matcherSimulationHeader.group(1)) * 1000.0; // converting KT to tons
                            heightOfBurst = Double.valueOf(matcherSimulationHeader.group(2)) * 1000.0; // converting km to m
                            mass = Double.valueOf(matcherSimulationHeader.group(3)); // not used, leaving in kg
                        }
                    }
                    if (lineNumber >= 16) {
                        // add the elements of the line (all doubes) to the a List 
                        List<Double> row = new ArrayList<>();
                        Scanner s = new Scanner(line);
                        while (s.hasNextDouble()) {
                            row.add(s.nextDouble());
                        }
                        // add the List row to the List dataArray
                        dataArray.add(row);
                    }
                }
            } else if (matcherSnHychemHeader.find()) {
                //snHychem = true;
                nColumns = 17;
                bandLabels = new String[]{"Band 01", "Band 02", "Band 03", "Band 04", 
                    "Band 05", "Band 06", "Band 07", "Band 08", "Band 09", "Band 10",
                    "Band 11", "Band 12", "Band 13", "Band 14", "Band 15", "Band 16"};
                yield = Double.valueOf(matcherSnHychemHeader.group(1)) * 1000.0; // converting KT to tons
                heightOfBurst = Double.valueOf(matcherSnHychemHeader.group(2)) * 1000.0; // converting km to m
                mass = Double.valueOf(matcherSnHychemHeader.group(3)); // // not used, leaving in kg
                while ((line = bufferedReader.readLine()) != null) {
                    lineNumber++;
                    if (lineNumber >= 7) {
                        // add the elements of the line (all doubes) to the a List 
                        List<Double> row = new ArrayList<>();
                        Scanner s = new Scanner(line);
                        while (s.hasNextDouble()) {
                            row.add(s.nextDouble());
                        }
                        // add the List row to the List dataArray
                        dataArray.add(row);
                    }
                }
            } else {
                System.out.println("WARNING: Unexpected content in file: " + lightwaveFile);
                return null;
            }                
        } catch (IOException ex) {
            Logger.getLogger(LightwaveFXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        // create Waveform objects for each band
        if (dataArray.size() > 0) {
            // extract the times from dataArray
            double[] times = dataArray.stream().map(innerList -> innerList.get(0)).collect(Collectors.toList()).stream().mapToDouble(d -> d).toArray();
            double[][] sensorPower = new double[times.length][sensorSpectralWeightsList.size()] ;
            // loop through all power columns in dataArray
            for (int columnIndex = 1; columnIndex < dataArray.get(0).size(); columnIndex++) {
                // I can't loop through the columns with the statement above used for the times because the lambda function complains.  
                List<Double> powerList = new ArrayList<>();
                for (List<Double> row:dataArray) {
                    powerList.add(row.get(columnIndex));
                }
                double[] power = powerList.stream().mapToDouble(d ->d).toArray();
                // now make Waveform Object and add to array list
                Waveform currentBandWaveform = new Waveform(times,power);
                currentBandWaveform.setBandLabel(bandLabels[columnIndex-1]);
                currentBandWaveform.setHeightOfBurst(heightOfBurst);
                currentBandWaveform.setSurfaceMaterial(surfaceMaterial);
                currentBandWaveform.setMass(mass);
                currentBandWaveform.setYield(yield);
                currentBandWaveform.setBand(columnIndex - spectralBandsColumnOffset); // This doesn't apply to first 3 entries of the community Hychem file - Si, S4, Thermal...what to do?
                currentBandWaveform.setDataSource(lightwaveFile);
                waveformList.add(currentBandWaveform);
                // Add this band's contribution to the combined response for each sensor in the sensorSpectralWeightsList
                // for community Hychem, spectral bands 1 - 15 are in column indexs 4 - 18 of the dataArray, Band 16 is not used
                // for snHychem, spectral bands 1 - 15 are in column indexs 1 - 15 of the dataArray, Band 16 is not used
                if (columnIndex > spectralBandsColumnOffset && columnIndex < (nColumns-1)) { //(nColumns-1) because coulumn for band 16 isn't used (sensor spectral weights don't exit in input file)
                    for (int sensorIndex = 0; sensorIndex < sensorSpectralWeightsList.size(); sensorIndex++) {
                        for (int timeIndex = 0; timeIndex < times.length; timeIndex++){
                            sensorPower[timeIndex][sensorIndex] = sensorPower[timeIndex][sensorIndex] + power[timeIndex] * sensorSpectralWeightsList.get(sensorIndex).spectralWeights[columnIndex - (spectralBandsColumnOffset+1)];
                        }
                    }
                }
            }
            // now make Waveform Objects for each sensor and add to array list 
            for (int sensorIndex = 0; sensorIndex < sensorSpectralWeightsList.size(); sensorIndex++) {
                double[] power = new double[times.length];
                for (int timeIndex = 0; timeIndex < times.length; timeIndex++){ 
                    power [timeIndex] = sensorPower[timeIndex][sensorIndex];
                }
                Waveform currentSensorWaveform = new Waveform(times,power);
                currentSensorWaveform.setBandLabel(sensorSpectralWeightsList.get(sensorIndex).getSensorName());
                currentSensorWaveform.setBand(0); // This doesn't apply to sensors...what to do?
                currentSensorWaveform.setHeightOfBurst(heightOfBurst);
                currentSensorWaveform.setSurfaceMaterial(surfaceMaterial);
                currentSensorWaveform.setMass(mass);
                currentSensorWaveform.setYield(yield);
                currentSensorWaveform.setDataSource(lightwaveFile);
                waveformList.add(currentSensorWaveform);
            }
            return waveformList;
        } else {
            System.out.println("WARNING: no data was found in the file " + lightwaveFile);
            return null;
        }
    }


    public static List<Waveform> readCTHFile(String lightwaveFile, List<SensorOperations.SensorSpectralWeights> sensorSpectralWeightsList) throws FileNotFoundException  {
        /* This function was written for CTH - OPTSIG Output files.
         * It assumes the 15-band version.  There is also an 8-band + Si Power version. 
         * The first line is the "FileHeader" line
         * The second line is the "Bands" line (and is not used or searched for)
         * The third line is minimum wavelength per band, "MinWl", line (and is not used or searched for)
         * The fourth line is maximum wavelength per band, "MaxWl" , line (and is not used or searched for)
         * The fifth line is the time/power header line (and is not used or searched for)
         * The sixth line is the individual "RunHeader" line(this will reoccur subsequently for different Look Angle/Azimuth combinations)
         * The data begins on line seven
         * 
         * An example is shown below:
         * POWER SPECTRA FROM CTH OPTSIG COMPUTATION -- FOR AIR CHEMISTRY
         *   HYCHEM band          1             2             3             4             5             6             7             8             9            10            11            12            13            14            15
         *   min.wl (nm)      3208.260      2642.283      2176.151      1792.251      1476.076      1215.678      1001.217       824.590       679.122       559.316       460.646       379.382       312.454       257.334       211.937
         *   max.wl (nm)     12407.070      3208.260      2642.283      2176.151      1792.251      1476.076      1215.678      1001.217       824.590       679.122       559.316       460.646       379.382       312.454       257.334
         *       time(s)      power(w)      power(w)      power(w)      power(w)      power(w)      power(w)      power(w)      power(w)      power(w)      power(w)      power(w)      power(w)      power(w)      power(w)      power(w)
         * 148 times for look angle   15 and azimuth    0 degrees
         *    0.0000E+00    2.1164E+06    3.7164E+06    6.4982E+06    1.1303E+07    1.9532E+07    3.3483E+07    5.6828E+07    7.0199E+07    7.8121E+07    7.3662E+07    5.0467E+07    2.1038E+07    3.3880E+06    1.0315E+05    1.3549E+02
         *
         * This function was modified to also process Hinterpol files:
         * An example of a Hinterpol optical.dat file
         * POWER AND YIELD SPECTRA FOR A BURST YIELD OF     10.00 KT DETONATED AT    0.00 KM.
         *  I_TELLER_LIGHT = 0
         *
         *     TIME (sec)  Si Power (W)    350-379 nm    379-460 nm    460-559 nm    559-679 nm    679-824 nm   824-1001 nm  1001-1215 nm  1215-1475 nm  1475-1791 nm  1791-2175 nm  2175-2640 nm  2640-3206 nm
         *                                   Band 13*       Band 12       Band 11       Band 10        Band 9        Band 8        Band 7        Band 6        Band 5        Band 4        Band 3        Band 2
         *     1.0000e-07    3.8304e+10    4.2800e+08    4.5253e+09    1.1728e+10    1.5771e+10    1.3394e+10    1.0793e+10    8.6216e+09    5.4386e+09    3.2516e+09    1.8773e+09    1.0515e+09    5.6576e+08
         *     1.1200e-07    3.9534e+10    4.4174e+08    4.6707e+09    1.2104e+10    1.6277e+10    1.3824e+10    1.1139e+10    8.8986e+09    5.6133e+09    3.3561e+09    1.9376e+09    1.0852e+09    5.8393e+08
        
        
        
         * An example of a Hinterpol optical_Si.dat file        
         *  POWER AND YIELD SPECTRA FOR A BURST YIELD OF     10.00 KT DETONATED AT    0.00 KM.
         *  I_TELLER_LIGHT = 0
         * 
         *     TIME (sec)      Si POWER     IIA Power     IIR Power     IIF Power    Si (Wiley)     S4* Power    500-700 nm
         *     1.0000e-07    3.8304e+10    3.5179e+10    3.7872e+10    3.8790e+10    3.8649e+10    1.3662e+10    2.4516e+10
         *     1.1200e-07    3.9534e+10    3.6309e+10    3.9089e+10    4.0036e+10    3.9890e+10    1.4101e+10    2.5304e+10        
        
        Pattern patternSimulationHeader = Pattern.compile("#   TOGLR\\s+(\\d+\\.?\\d*)KT\\s+(\\d+\\.?\\d*)KM\\s+(\\d+\\.?\\d*)kg");
         * Decoding the pattern above:  
                     * () surround the value to be captured in a group
                     * \\d is a digit
                     * \\s is any white space character
                     * \\. Is a period (just a . is any character)
                     * + means one or more
                     * ? means once or not at all
                     * * means zero or more times
                     * For example:  
                     * #   TOGLR\\s+ looks for the characters “#   TOGLR” followed by any white space
                     * (\\d+\\.?\\d*) captures one or more digit followed by one or no . followed by zero or more digits
                     * For more, see: https://docs.oracle.com/javase/7/docs/api/java/util/regex/Pattern.html 
                    * 
        
         * 
         * TO DO: 
         */
        
        String line;
        double yield = 0.0;
        double heightOfBurst = 0.0;
        double mass = 0.0;
        boolean hinterpolFile = false;
        boolean hinterpol12BandFile = false; 
        String surfaceMaterial = "Unknown";
        String[] bandLabels;
        int nColumns;
        List<Waveform> waveformList = new ArrayList<>();
        List<List<Double>> dataArray = new ArrayList<>();
        //
        // Parse file name to determine surface material , yield, and hob 
        // This assumes a filename ending in "_surfaceMaterial_integerYieldInTons_integerHeightOfBurstInMeters."
        // If this pattern isn't found, default values of 0 will be used
//        Pattern patternFileName = Pattern.compile("\\w+[_](\\w+)[_](\\w+)[_](\\w+)[.]\\w+"); //Original: w is any word character [a-zA-Z_0-9] which doesn't include . while S is any non-whitespace character
        Pattern patternFileName = Pattern.compile("\\S+[_](\\S+)[_](\\S+)[_](\\S+)[.]\\w+"); //Update, now decimal places can be used in surface material, yiels, and hob
        Matcher matcherFileName = patternFileName.matcher(lightwaveFile);
        if (matcherFileName.find()) {
            surfaceMaterial = matcherFileName.group(1);
            yield = Double.valueOf(matcherFileName.group(2));
            heightOfBurst = Double.valueOf(matcherFileName.group(3));
        }
        // Build pattern matchers
        Pattern pattern15BandFileHeader = Pattern.compile("POWER SPECTRA FROM CTH OPTSIG COMPUTATION -- FOR AIR CHEMISTRY");
        Pattern pattern8BandFileHeader = Pattern.compile("POWER SPECTRA FROM A CTH OPTSIG COMPUTATION");
        Pattern patternRunHeader = Pattern.compile("(\\d+) times for look angle\\s+ (\\d+) and azimuth\\s+ (\\d+) ");
        String basicPatternDataString = "\\s+([-+]?[0-9]*\\.[0-9]+[eE][-+]?[0-9]+)";
        String patternDataString = "";  // original which assumes time: String patternDataString = "" + basicPatternDataString; 
        // Addiitonal pattern matchers for Hinterpol files
        Pattern patternHinterpolFileHeader = Pattern.compile("POWER AND YIELD SPECTRA FOR A BURST YIELD OF\\s+(\\d+\\.?\\d*) KT DETONATED AT\\s+(\\d+\\.?\\d*) KM.");
        Pattern pattern12BandHinterpolFileHeader = Pattern.compile("Band 12");
        Pattern pattern7SensorHinterpolFileHeader = Pattern.compile("Si POWER     IIA Power");

        try (FileReader fileReader = new FileReader(lightwaveFile)) {
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            // Read the first line to determine which type of file follows
            line = bufferedReader.readLine();
            Matcher matcher15BandFileHeader = pattern15BandFileHeader.matcher(line);
            Matcher matcher8BandFileHeader = pattern8BandFileHeader.matcher(line);
            Matcher matcherHinterpolFileHeader = patternHinterpolFileHeader.matcher(line);
            if (matcher15BandFileHeader.find()) {
                nColumns = 16;
                bandLabels = new String[]{"Band 01", "Band 02", "Band 03", "Band 04",
                    "Band 05", "Band 06", "Band 07", "Band 08", "Band 09", "Band 10",
                    "Band 11", "Band 12", "Band 13", "Band 14", "Band 15"};
            } else if (matcher8BandFileHeader.find()) {
                nColumns = 10;
                bandLabels = new String[]{"Si-Power", "Band 14", "Band 13",
                    "Band 12", "Band 11", "Band 10", "Band 9", "Band 8", "Band 7"};
            } else if (matcherHinterpolFileHeader.find()) {
                hinterpolFile = true;
                yield = Double.valueOf(matcherHinterpolFileHeader.group(1)) * 1000.0; // converting KT to tons
                heightOfBurst = Double.valueOf(matcherHinterpolFileHeader.group(2)) * 1000.0; // converting km to m
                // Continue reading the header lines to determine format of current file
                bufferedReader.readLine();
                bufferedReader.readLine();
                line = bufferedReader.readLine();
                Matcher matcher7SensorHinterpolFileHeader = pattern7SensorHinterpolFileHeader.matcher(line);
                if (matcher7SensorHinterpolFileHeader.find()) {
                        nColumns = 8;
                        bandLabels = new String[]{"Si POWER", "IIA Power", "IIR Power", 
                            "IIF Power", "Si (Wiley)", "S4* Power", "500-700 nm"};
                } else {
                    line = bufferedReader.readLine();
                    Matcher matcher12BandHinterpolFileHeader = pattern12BandHinterpolFileHeader.matcher(line);
                    if (matcher12BandHinterpolFileHeader.find()) {
                        hinterpol12BandFile = true;
                        nColumns = 14;
                        bandLabels = new String[]{"Si Power (W)", "Band 13*", "Band 12",
                            "Band 11", "Band 10", "Band 09", "Band 08", "Band 07", "Band 06",
                            "Band 05", "Band 04", "Band 03", "Band 02"};
                    } else {
                        System.out.println("WARNING: Unexpected content in Hinterpol file: " + lightwaveFile);
                        return null;
                    }
                }
            } else {
                System.out.println("WARNING: Unexpected content in file: " + lightwaveFile);
                return null;
            }
            
            if (hinterpolFile == true) {
                // read the rest of the file (with unknown lenght) and create the dataArray
                while ((line = bufferedReader.readLine()) != null) {
                    // add the elements of the line (all doubes) to the a List 
                    List<Double> row = new ArrayList<>();
                    Scanner s = new Scanner(line);
                    while (s.hasNextDouble()) {
                        row.add(s.nextDouble());
                    }
                    // add the List row to the List dataArray
                    dataArray.add(row);
                }
                if (hinterpol12BandFile == true) {
                    // create Waveform objects for each band/sensor column
                    if (dataArray.size() > 0) {
                        // extract the times from dataArray
                        double[] times = dataArray.stream().map(innerList -> innerList.get(0)).collect(Collectors.toList()).stream().mapToDouble(d -> d).toArray();
                        double[][] sensorPower = new double[times.length][sensorSpectralWeightsList.size()] ;
                        // loop through all power columns in dataArray
                        for (int columnIndex = 1; columnIndex < dataArray.get(0).size(); columnIndex++) {
                            // I can't loop through the columns with the statement above used for the times because the lambda function complains.  
                            List<Double> powerList = new ArrayList<>();
                            for (List<Double> row:dataArray) {
                                powerList.add(row.get(columnIndex));
                            }
                            double[] power = powerList.stream().mapToDouble(d ->d).toArray();
                            // now make Waveform Object and add to array list
                            Waveform currentBandWaveform = new Waveform(times,power);
                            currentBandWaveform.setBandLabel(bandLabels[columnIndex-1]);
                            if (columnIndex == 1) {
                                // Si Power column
                                currentBandWaveform.setBand(0);
                            } else {
                                currentBandWaveform.setBand(14 - columnIndex); // The bands run 13 to 2 backwards
                            }
                            currentBandWaveform.setHeightOfBurst(heightOfBurst);
                            currentBandWaveform.setSurfaceMaterial(surfaceMaterial);
                            currentBandWaveform.setMass(mass);
                            currentBandWaveform.setYield(yield);
                            currentBandWaveform.setDataSource(lightwaveFile);
                            waveformList.add(currentBandWaveform);
                            // Add this band's contribution to the combined response for each sensor in the sensorSpectralWeightsList
                            // spectral bands 2 - 13 are in column indexs 13 - 2 of the dataArray in reverse order, i.e., Band 13 is in index 2, Band 2 is in index 13
                            if (columnIndex > 1 && columnIndex < 14) {
                                for (int sensorIndex = 0; sensorIndex < sensorSpectralWeightsList.size(); sensorIndex++) {
                                    for (int timeIndex = 0; timeIndex < times.length; timeIndex++){
                                        sensorPower[timeIndex][sensorIndex] = sensorPower[timeIndex][sensorIndex] + power[timeIndex] * sensorSpectralWeightsList.get(sensorIndex).spectralWeights[14 - columnIndex];
                                    }
                                }
                            }
                        }
                        // now make Waveform Objects for each sensor and add to array list 
                        for (int sensorIndex = 0; sensorIndex < sensorSpectralWeightsList.size(); sensorIndex++) {
                            double[] power = new double[times.length];
                            for (int timeIndex = 0; timeIndex < times.length; timeIndex++){ 
                                power [timeIndex] = sensorPower[timeIndex][sensorIndex];
                            }
                            Waveform currentSensorWaveform = new Waveform(times,power);
                            currentSensorWaveform.setBandLabel(sensorSpectralWeightsList.get(sensorIndex).getSensorName());
                            currentSensorWaveform.setBand(0); // This doesn't apply to sensors...what to do?
                            currentSensorWaveform.setHeightOfBurst(heightOfBurst);
                            currentSensorWaveform.setSurfaceMaterial(surfaceMaterial);
                            currentSensorWaveform.setMass(mass);
                            currentSensorWaveform.setYield(yield);
                            currentSensorWaveform.setDataSource(lightwaveFile);
                            waveformList.add(currentSensorWaveform);
                        }
                    } else {
                        System.out.println("WARNING: no data was found in the file " + lightwaveFile);
                        return null;
                    }
                    
                    
                
                } else {
                    // Current file has no spectral data, only pre-computed sensor response (and 500-700 nm)
                    // create Waveform objects for each band/sensor column
                    if (dataArray.size() > 0) {
                        // extract the times from dataArray
                        double[] times = dataArray.stream().map(innerList -> innerList.get(0)).collect(Collectors.toList()).stream().mapToDouble(d -> d).toArray();
                        double[][] sensorPower = new double[times.length][sensorSpectralWeightsList.size()] ;
                        // loop through all power columns in dataArray
                        for (int columnIndex = 1; columnIndex < dataArray.get(0).size(); columnIndex++) {
                            // I can't loop through the columns with the statement above used for the times because the lambda function complains.  
                            List<Double> powerList = new ArrayList<>();
                            for (List<Double> row:dataArray) {
                                powerList.add(row.get(columnIndex));
                            }
                            double[] power = powerList.stream().mapToDouble(d ->d).toArray();
                            // now make Waveform Object and add to array list
                            Waveform currentBandWaveform = new Waveform(times,power);
                            currentBandWaveform.setBandLabel(bandLabels[columnIndex-1]);
                            currentBandWaveform.setBand(0); // This doesn't apply to first 3 entries - Si, S4, Thermal...what to do?
                            currentBandWaveform.setHeightOfBurst(heightOfBurst);
                            currentBandWaveform.setSurfaceMaterial(surfaceMaterial);
                            currentBandWaveform.setMass(mass);
                            currentBandWaveform.setYield(yield);
                            currentBandWaveform.setDataSource(lightwaveFile);
                            waveformList.add(currentBandWaveform);
                        }
                    } else {
                        System.out.println("WARNING: no data was found in the file " + lightwaveFile);
                        return null;
                    }
                }
        
        
            } else {
                // This path is for CTH OPTSIG Files
                // create the pattern for the data line based on number of columns 
                for (int ii = 0; ii < nColumns; ii++) {
                    patternDataString = patternDataString + basicPatternDataString;
                }
                Pattern patternData = Pattern.compile(patternDataString);
                // continue reading the remainder of the file
                int nTimes = 0;
                double lookAngle = 0;
                double azimuth = 0;
                int dataIndex = 0;

                while ((line = bufferedReader.readLine()) != null) {
                    // test this line for the run header or data patterns
                    Matcher matcherRunHeader = patternRunHeader.matcher(line);
                    Matcher matcherData = patternData.matcher(line);
                    // look for the RunHeader
                    if (matcherRunHeader.find()) {
                        nTimes = Integer.valueOf(matcherRunHeader.group(1));
                        lookAngle = Double.valueOf(matcherRunHeader.group(2));
                        azimuth = Double.valueOf(matcherRunHeader.group(3));
                        dataIndex = 0; //set to zero each time a new Run Header is found 
                        dataArray.clear(); // clear each time a new Run Header is found
                    } else if (matcherData.find()) {
                        // add the elements of the line (all doubes) to the a List 
                        List<Double> row = new ArrayList<>();
                        Scanner s = new Scanner(line);
                        while (s.hasNextDouble()) {
                            row.add(s.nextDouble());
                        }
                        // add the List row to the List dataArray
                        dataArray.add(row);
                        dataIndex++;
                        if (dataIndex == nTimes) {
                            // reached the end of the current run's data...process the dataArray
                            // extract the times from dataArray
                            double[] times = dataArray.stream().map(innerList -> innerList.get(0)).collect(Collectors.toList()).stream().mapToDouble(d -> d).toArray();
                            double[][] sensorPower = new double[times.length][sensorSpectralWeightsList.size()];
                            // loop through all power columns in dataArray
                            for (int columnIndex = 1; columnIndex < dataArray.get(0).size(); columnIndex++) {
                                // I can't loop through the columns with the statement above used for the times because the lambda function complains.  
                                List<Double> powerList = new ArrayList<>();
                                for (List<Double> dataRow : dataArray) {
                                    powerList.add(dataRow.get(columnIndex));
                                }
                                double[] power = powerList.stream().mapToDouble(d -> d).toArray();
                                // now make Waveform Object and add to array list
                                Waveform currentBandWaveform = new Waveform(times, power);
                                currentBandWaveform.setBandLabel(bandLabels[columnIndex - 1]);
                                if (nColumns == 16) {
                                    currentBandWaveform.setBand(columnIndex);
                                } else {
                                    if (columnIndex == 1) {
                                        currentBandWaveform.setBand(0); // this is the Si-Power column and band is N/A
                                    } else {
                                        currentBandWaveform.setBand(16 - columnIndex); // This is because the 8 band file goes from 14 to 7
                                    }
                                }
                                currentBandWaveform.setHeightOfBurst(heightOfBurst);
                                currentBandWaveform.setSurfaceMaterial(surfaceMaterial);
                                currentBandWaveform.setMass(mass);
                                currentBandWaveform.setYield(yield);
                                currentBandWaveform.setAzimuth(azimuth);
                                currentBandWaveform.setLookAngle(lookAngle);
                                currentBandWaveform.setDataSource(lightwaveFile);
                                waveformList.add(currentBandWaveform);
                                // Add this band's contribution to the combined response for each sensor in the sensorSpectralWeightsList
                                if (nColumns == 16) {
                                    // columns 1 - 15 correspond to the bands 1 - 15
                                    for (int sensorIndex = 0; sensorIndex < sensorSpectralWeightsList.size(); sensorIndex++) {
                                        for (int timeIndex = 0; timeIndex < times.length; timeIndex++) {
                                            sensorPower[timeIndex][sensorIndex] = sensorPower[timeIndex][sensorIndex] + power[timeIndex] * sensorSpectralWeightsList.get(sensorIndex).spectralWeights[columnIndex - 1];
                                        }
                                    }
                                } else {
                                    // columns 1 - 9 correspond to the Si-Power + bands 14 - 7; 16-columnIndex = band, 16-columnIndex-1 = band index in teh spectralWeights array
                                    if (columnIndex > 1) {
                                        for (int sensorIndex = 0; sensorIndex < sensorSpectralWeightsList.size(); sensorIndex++) {
                                            for (int timeIndex = 0; timeIndex < times.length; timeIndex++) {
                                                sensorPower[timeIndex][sensorIndex] = sensorPower[timeIndex][sensorIndex] + power[timeIndex] * sensorSpectralWeightsList.get(sensorIndex).spectralWeights[16 - columnIndex - 1];
                                            }
                                        }
                                    }
                                }
                            }
                            // now make Waveform Objects for each sensor and add to array list 
                            for (int sensorIndex = 0; sensorIndex < sensorSpectralWeightsList.size(); sensorIndex++) {
                                double[] power = new double[times.length];
                                for (int timeIndex = 0; timeIndex < times.length; timeIndex++) {
                                    power[timeIndex] = sensorPower[timeIndex][sensorIndex];
                                }
                                Waveform currentSensorWaveform = new Waveform(times, power);
                                currentSensorWaveform.setBandLabel(sensorSpectralWeightsList.get(sensorIndex).getSensorName());
                                currentSensorWaveform.setBand(0); // This doesn't apply to sensors...what to do?
                                currentSensorWaveform.setHeightOfBurst(heightOfBurst);
                                currentSensorWaveform.setSurfaceMaterial(surfaceMaterial);
                                currentSensorWaveform.setMass(mass);
                                currentSensorWaveform.setYield(yield);
                                currentSensorWaveform.setAzimuth(azimuth);
                                currentSensorWaveform.setLookAngle(lookAngle);
                                currentSensorWaveform.setDataSource(lightwaveFile);
                                waveformList.add(currentSensorWaveform);
                            }
                        }
                    } else {
                        //System.out.println(" Nothing interesting on this line: " + line);
                    }
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(LightwaveFXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return waveformList;
    }

    public static List<Waveform> readAndsasOpticalOutFile(String lightwaveFile) throws FileNotFoundException  {
         /* This function reads QUERY optical epro dump files CTH - OPTSIG Output files.
         *
         * TBD: 
         * Finish the intro to describe file format... 
         * Re-code like other read functions with List objects to eliminate the need to size array based on epro type
         * Also read rows by stream, has next double
         */
        String line;
        double yield = 0.0;
        double heightOfBurst = 0.0;
        double mass = 0.0;
        double lookAngle = 0.0;
        double azimuth = 0.0;
        String surfaceMaterial = "Unknown";
        List<Waveform> waveformList = new ArrayList<>();
        int nTimes = 0;
        double[] times = null;
        double[] power = null;
        int dataIndex = 0;
        Pattern patternFileHeader = Pattern.compile("\\s+(\\w+)\\s+(\\w+)\\s+(\\w+-\\w+-\\w+)\\s(\\w+:\\w+:\\w+.\\w+)\\s+(\\w+)\\s+(\\w+)\\s+(\\w+)\\s+(\\w+)");
        Pattern patternLensHeader = Pattern.compile("Lens Transmissivity is ([0-9]*\\.[0-9]+)");
        Pattern patternData = Pattern.compile("\\s+([-+]?[0-9]*\\.[0-9]+)\\s+([0-9]*\\.[0-9]+)\\s+([-+]?[0-9]*\\.[0-9]+[eE][-+]?[0-9]+)");
        String eproType = null;
        String tagNumber;
        String dateTime;
        String system;
        String groundStation;
        String iron;
        String sev;
        String sensorLabel = null;
        double lensTransmissivity;
        // open the current file and read the data 
        try (FileReader fileReader = new FileReader(lightwaveFile)) {
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            // read and parse the file one line at a time 
            while ((line = bufferedReader.readLine()) != null) {
                // Evaluate the current line against all patterns
                Matcher matcherFileHeader = patternFileHeader.matcher(line);
                Matcher matcherLensHeader = patternLensHeader.matcher(line);
                Matcher matcherData = patternData.matcher(line);
                if (matcherFileHeader.find()) {
                    eproType = matcherFileHeader.group(1);
                    tagNumber = matcherFileHeader.group(2);
                    dateTime = matcherFileHeader.group(3) + " " + matcherFileHeader.group(4);
                    system = matcherFileHeader.group(5);
                    groundStation = matcherFileHeader.group(6);
                    iron = matcherFileHeader.group(7);
                    sev = matcherFileHeader.group(8);
                    sensorLabel = iron + "" + eproType + " " + tagNumber;
                    switch (eproType) {
                        case "bdy_t ":
                            nTimes = 48;
                            break;
                        case "bdy_d_r":
                            nTimes = 143;
                            break;
                        case "bdy_t_f":
                            nTimes = 48;
                            break;
                        case "bdye_f":
                            nTimes = 112;
                            break;
                        case "bdy_d_f":
                            nTimes = 144;
                            break;
                        case "bdyt3":
                            nTimes = 48;
                            break;
                        case "bdye3":
                            nTimes = 112;
                            break;
                        case "bdyd3":
                            nTimes = 144;
                            break;
                        case "ysl_long":
                            nTimes = 252;
                            break;
                        case "ysl_short":
                            nTimes = 252;
                            break;
                    }
                    times = new double[nTimes];
                    power = new double[nTimes];
                } else if (matcherLensHeader.find()) {
                    lensTransmissivity = Double.valueOf(matcherLensHeader.group(1));
                } else if (matcherData.find()) {
                    times[dataIndex] = Double.valueOf(matcherData.group(1)) / 1000.0;
                    if (eproType.contains("ysl_")) {
                        power[dataIndex] = Double.valueOf(matcherData.group(3)) * 4.0 * Math.PI * Math.pow(3582.2E6, 2.0) / 0.87;
                        //ASSUMING DSP altitude in cm with zero look angle, and 87% light transmittance(clear air)
                    } else {
                        power[dataIndex] = Double.valueOf(matcherData.group(3)) * 4.0 * Math.PI * Math.pow(2042.2E6, 2.0) / 0.87;
                        //ASSUMING GPS altitude in cm with zero look angle, and 87% light transmittance(clear air)
                    }
                } else {
                    //System.out.println(" Nothing interesting on this line: " + line);
                }
            }// Done parsing through the current line
            Waveform currentSensorWaveform = new Waveform(times, power);
            currentSensorWaveform.setBandLabel(sensorLabel);
            currentSensorWaveform.setBand(0); // This doesn't apply to sensors...what to do?
            currentSensorWaveform.setHeightOfBurst(heightOfBurst);
            currentSensorWaveform.setSurfaceMaterial(surfaceMaterial);
            currentSensorWaveform.setMass(mass);
            currentSensorWaveform.setYield(yield);
            currentSensorWaveform.setAzimuth(azimuth);
            currentSensorWaveform.setLookAngle(lookAngle);
            currentSensorWaveform.setDataSource(lightwaveFile);
            waveformList.add(currentSensorWaveform);
        } catch (IOException ex) {
            Logger.getLogger(LightwaveFXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return waveformList;
    }
    
        
    
        
    public static List<Waveform> readCSVFile(String lightwaveFile) throws FileNotFoundException {
        /* This function reads a generic CSV file.
         * It assumes data in columns with time first, followed by one or more colums of power
         * 
         *
         * TBD: 
         * Finish the intro to describe file format... 
         * NOTE: The units of the generic csv file may be random.  time is expected in seconds, but may not be.  power is expected in watts at source but may not be...what to do?  Throw a pop-ip window telling user whenever a .csv is selected that sec/W are expected and have them input conversion factors? that might be straight forward
         *  if implementing the "request user input on adjusting time, add a factor in the lambda function mapToDouble(d -> d)  to mapToDouble(d -> d*timeFactor) where timeFactor = (1/1000) for converting ms to seconds
         *  CONSIDER REDOING time assumptions in ALL READERS AND PLOT FUNCTIONS...i think paradigm is to store in seconds,  that makes sense, but be consistent
         */
        String line;
        double yield = 0.0;
        double heightOfBurst = 0.0;
        double mass = 0.0;
        double lookAngle = 0.0;
        double azimuth = 0.0;
        String surfaceMaterial = "Unknown";
        List<Waveform> waveformList = new ArrayList<>();
        List<List<Double>> dataArray = new ArrayList<>();
        String[] bandLabels = new String[0];
        // open the current file and read the data 
        try (FileReader fileReader = new FileReader(lightwaveFile)) {
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            // read and parse the file one line at a time 
            boolean dataFound = false;
            while ((line = bufferedReader.readLine()) != null) {
                String[] CSV = line.split(",");
                // Process this line if 2 or more values are found (assuming a time and at least 1 data column)
                if (CSV.length > 1) {
                    // Check if this line has header info or data
                    if (!dataFound) {
                        try { 
                            double d = Double.parseDouble(CSV[0]);
                            dataFound = true;
                        } catch (NumberFormatException nfe) {
                            // Number not found, assume it is a header
                            bandLabels = new String[CSV.length-1];
                            for (int ii = 1; ii < CSV.length; ii++) {
                                bandLabels[ii-1] = CSV[ii];
                            }
                        }
                    } 
                    if (dataFound) {
                        List<Double> row = Arrays.asList(CSV).stream().map(Double::parseDouble).collect(Collectors.toList());
                        // add the List row to the List dataArray
                        dataArray.add(row);
                    }
                } else {
                    System.out.println("This line doesn't have valid data");
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(LightwaveFXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        // create Waveform objects for each column
        if (dataArray.size() > 0) {
            // extract the times from dataArray
            double[] times = dataArray.stream().map(innerList -> innerList.get(0)).collect(Collectors.toList()).stream().mapToDouble(d -> d).toArray();
//            double[][] sensorPower = new double[times.length][sensorSpectralWeightsList.size()] ;
            // loop through all power columns in dataArray
            for (int columnIndex = 1; columnIndex < dataArray.get(0).size(); columnIndex++) {
                // I can't loop through the columns with the statement above used for the times because the lambda function complains.  
                List<Double> powerList = new ArrayList<>();
                for (List<Double> row : dataArray) {
                    powerList.add(row.get(columnIndex));
                }
                double[] power = powerList.stream().mapToDouble(d -> d).toArray();
                // now make Waveform Object and add to array list
                Waveform currentBandWaveform = new Waveform(times, power);
                if (bandLabels.length > 0) {
                    currentBandWaveform.setBandLabel(bandLabels[columnIndex - 1]);
                } else {
                    currentBandWaveform.setBandLabel("Waveform " + String.valueOf(columnIndex - 1));
                }
                currentBandWaveform.setBand(0); // This doesn't apply...what to do?
                currentBandWaveform.setHeightOfBurst(heightOfBurst);
                currentBandWaveform.setSurfaceMaterial(surfaceMaterial);
                currentBandWaveform.setMass(mass);
                currentBandWaveform.setYield(yield);
                currentBandWaveform.setAzimuth(azimuth);
                currentBandWaveform.setLookAngle(lookAngle);
                currentBandWaveform.setDataSource(lightwaveFile);
                waveformList.add(currentBandWaveform);
            }
            return waveformList;
        } else {
            System.out.println("WARNING: no data was found in the file " + lightwaveFile);
            return null;
        }
    }

}














    
    
    

