/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lightwave;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 *
 * @author David Smuck
 */
public class SensorOperations {

    public static List<SensorSpectralWeights> loadSensorSpectralWeights(String SensorSpectralWeightsFileFQN) {
        String line;
        List<SensorSpectralWeights> sensorSpectralWeightsList = new ArrayList<>();
        File SensorSpectralWeightsFile = new File(SensorSpectralWeightsFileFQN);
        if (SensorSpectralWeightsFile.exists()) {
            //System.out.println("the file " + SensorSpectralWeightsFileFQN + " exists");
            try (BufferedReader bufferedReader = new BufferedReader(new FileReader(SensorSpectralWeightsFileFQN))) {
                while ((line = bufferedReader.readLine()) != null) {
                    if (!line.contains("/")) {
                        sensorSpectralWeightsList.add(new SensorSpectralWeights(line.split(",")));
                    }
                }
            } catch (IOException e) {
            }
            return sensorSpectralWeightsList;
        } else {
            System.out.println("the file " + SensorSpectralWeightsFileFQN + " DOES NOT exist...using generic Si");
            line = "Silicon,  0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.170, 0.950, 0.890, 0.620, 0.370, 0.120, 0.010, 0.000, 0.000";
            sensorSpectralWeightsList.add(new SensorSpectralWeights(line.split(",")));
            return sensorSpectralWeightsList;
        }
    }

    public static class SensorSpectralWeights {

        String sensorName;
        double[] spectralWeights = new double[15];

        // Constructor
        private SensorSpectralWeights(String[] CSV) {
            sensorName = CSV[0];
            for (int ii = 0; ii < spectralWeights.length; ii++) {
                spectralWeights[ii] = Double.valueOf(CSV[ii + 1]);
            }
        }

        // Getters
        public String getSensorName() {
            return sensorName;
        }

        public double[] getSpectralWeights() {
            return Arrays.copyOf(spectralWeights, spectralWeights.length);
        }

    }

}
